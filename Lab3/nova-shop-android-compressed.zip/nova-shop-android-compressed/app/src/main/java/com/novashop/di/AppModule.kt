package com.novashop.di

import android.content.Context
import androidx.room.Room
import com.novashop.BuildConfig
import com.novashop.data.api.AuthInterceptor
import com.novashop.data.api.CartItemDeserializer
import com.novashop.data.api.NovaShopApi
import com.novashop.data.api.Order
import com.novashop.data.api.OrderDeserializer
import com.novashop.data.api.ProductDeserializer
import com.novashop.data.api.RecommendationDeserializer
import com.novashop.data.api.TokenManager
import com.novashop.data.api.CartItem
import com.novashop.data.api.Product
import com.novashop.data.api.Recommendation
import com.novashop.data.db.NovaShopDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides @Singleton
    fun provideOkHttpClient(authInterceptor: AuthInterceptor): OkHttpClient =
        OkHttpClient.Builder()
            .addInterceptor(authInterceptor)
            .addInterceptor(HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BODY
            })
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .build()

    @Provides @Singleton
    fun provideGson(): Gson = GsonBuilder()
        .registerTypeAdapter(Product::class.java, ProductDeserializer)
        .registerTypeAdapter(CartItem::class.java, CartItemDeserializer)
        .registerTypeAdapter(Order::class.java, OrderDeserializer)
        .registerTypeAdapter(Recommendation::class.java, RecommendationDeserializer)
        .create()

    @Provides @Singleton
    fun provideRetrofit(client: OkHttpClient, gson: Gson): Retrofit =
        Retrofit.Builder()
            .baseUrl(BuildConfig.BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create(gson))
            .build()

    @Provides @Singleton
    fun provideApi(retrofit: Retrofit): NovaShopApi =
        retrofit.create(NovaShopApi::class.java)

    @Provides @Singleton
    fun provideDatabase(@ApplicationContext ctx: Context): NovaShopDatabase =
        Room.databaseBuilder(ctx, NovaShopDatabase::class.java, "novashop.db")
            .fallbackToDestructiveMigration()
            .build()

    @Provides fun provideWishlistDao(db: NovaShopDatabase) = db.wishlistDao()
    @Provides fun provideCartCacheDao(db: NovaShopDatabase) = db.cartCacheDao()
}
