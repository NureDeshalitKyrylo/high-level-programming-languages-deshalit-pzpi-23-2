package com.novashop.data.api

import retrofit2.Response
import retrofit2.http.*

interface NovaShopApi {

    // ── Auth ─────────────────────────────────────────────────

    @POST("auth/login")
    suspend fun login(@Body request: LoginRequest): Response<AuthResponse>

    @POST("auth/register")
    suspend fun register(@Body request: RegisterRequest): Response<AuthResponse>

    @POST("auth/refresh")
    suspend fun refresh(@Body request: RefreshRequest): Response<RefreshResponse>

    @GET("auth/me")
    suspend fun getMe(): Response<User>

    @POST("auth/logout")
    suspend fun logout(@Body body: Map<String, String>): Response<Unit>

    // ── Products ─────────────────────────────────────────────

    @GET("products")
    suspend fun getProducts(
        @Query("page")      page:     Int    = 1,
        @Query("limit")     limit:    Int    = 12,
        @Query("search")    search:   String? = null,
        @Query("category")  category: String? = null,
        @Query("tag")       tag:      String? = null,
        @Query("sort")      sort:     String  = "created_at",
        @Query("order")     order:    String  = "desc",
        @Query("featured")  featured: Boolean? = null
    ): Response<ProductsResponse>

    @GET("products/{slug}")
    suspend fun getProduct(@Path("slug") slug: String): Response<Product>

    @GET("categories")
    suspend fun getCategories(): Response<List<Category>>

    // ── Cart ─────────────────────────────────────────────────

    @GET("cart")
    suspend fun getCart(): Response<List<CartItem>>

    @POST("cart/items")
    suspend fun addToCart(@Body request: AddToCartRequest): Response<List<CartItem>>

    @PATCH("cart/items/{id}")
    suspend fun updateCartItem(
        @Path("id") id: String,
        @Body request: UpdateCartRequest
    ): Response<List<CartItem>>

    @DELETE("cart/items/{id}")
    suspend fun removeCartItem(@Path("id") id: String): Response<List<CartItem>>

    @DELETE("cart")
    suspend fun clearCart(): Response<List<CartItem>>

    // ── Orders ────────────────────────────────────────────────

    @POST("orders")
    suspend fun checkout(@Body request: CheckoutRequest): Response<Order>

    @GET("orders")
    suspend fun getOrders(): Response<List<Order>>

    @GET("orders/{id}")
    suspend fun getOrder(@Path("id") id: String): Response<Order>

    // ── Recommendations ──────────────────────────────────────

    @GET("recommendations")
    suspend fun getRecommendations(
        @Query("limit") limit: Int = 8
    ): Response<List<Recommendation>>
}
