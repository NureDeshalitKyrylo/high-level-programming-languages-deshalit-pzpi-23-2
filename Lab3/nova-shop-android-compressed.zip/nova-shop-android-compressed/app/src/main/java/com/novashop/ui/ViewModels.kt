package com.novashop.ui

import androidx.lifecycle.*
import com.novashop.data.api.*
import com.novashop.data.db.WishlistEntity
import com.novashop.data.repository.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

private fun String.moneyValue(): Double =
    filter { it.isDigit() || it == '.' || it == '-' }.toDoubleOrNull() ?: 0.0

// ── Auth ViewModel ────────────────────────────────────────────

@HiltViewModel
class AuthViewModel @Inject constructor(
    private val repo: AuthRepository
) : ViewModel() {

    private val _state = MutableLiveData<Result<User>>()
    val state: LiveData<Result<User>> = _state

    val isLoggedIn: LiveData<Boolean> = repo.isLoggedIn().asLiveData()

    private var _currentUser: User? = null
    val currentUser get() = _currentUser

    init {
        viewModelScope.launch {
            _currentUser = repo.getCachedUser()
        }
    }

    fun login(email: String, password: String) = viewModelScope.launch {
        _state.value = Result.Loading
        _state.value = repo.login(email, password).also {
            if (it is Result.Success) _currentUser = it.data
        }
    }

    fun register(email: String, password: String, name: String) = viewModelScope.launch {
        _state.value = Result.Loading
        _state.value = repo.register(email, password, name).also {
            if (it is Result.Success) _currentUser = it.data
        }
    }

    fun logout() = viewModelScope.launch { repo.logout(); _currentUser = null }
}

// ── Catalog ViewModel ─────────────────────────────────────────

@HiltViewModel
class CatalogViewModel @Inject constructor(
    private val productRepo: ProductRepository,
    private val wishlistRepo: WishlistRepository
) : ViewModel() {

    private val _products     = MutableLiveData<Result<ProductsResponse>>()
    val products: LiveData<Result<ProductsResponse>> = _products

    private val _categories   = MutableLiveData<Result<List<Category>>>()
    val categories: LiveData<Result<List<Category>>> = _categories

    var currentPage   = 1
    var totalPages    = 1
    var searchQuery   = ""
    var selectedCategory = ""
    var selectedTag   = ""
    var selectedSort  = "created_at"
    var selectedOrder = "desc"

    val wishlistIds = wishlistRepo.getAll()
        .map { list -> list.map { it.productId }.toSet() }
        .asLiveData()

    init { loadProducts(); loadCategories() }

    fun loadProducts(reset: Boolean = true) = viewModelScope.launch {
        if (reset) currentPage = 1
        _products.value = Result.Loading
        val result = productRepo.getProducts(
            page     = currentPage,
            search   = searchQuery.ifBlank { null },
            category = selectedCategory.ifBlank { null },
            tag      = selectedTag.ifBlank { null },
            sort     = selectedSort,
            order    = selectedOrder
        )
        if (result is Result.Success) {
            totalPages = (result.data.total + 11) / 12
        }
        _products.value = result
    }

    fun nextPage() {
        if (currentPage < totalPages) { currentPage++; loadProducts(false) }
    }

    fun prevPage() {
        if (currentPage > 1) { currentPage--; loadProducts(false) }
    }

    private fun loadCategories() = viewModelScope.launch {
        _categories.value = productRepo.getCategories()
    }

    fun toggleWishlist(product: Product) = viewModelScope.launch {
        wishlistRepo.toggle(product)
    }
}

// ── Product Detail ViewModel ──────────────────────────────────

@HiltViewModel
class ProductDetailViewModel @Inject constructor(
    private val productRepo: ProductRepository,
    private val cartRepo: CartRepository,
    private val wishlistRepo: WishlistRepository
) : ViewModel() {

    private val _product = MutableLiveData<Result<Product>>()
    val product: LiveData<Result<Product>> = _product

    private val _cartResult = MutableLiveData<Result<List<CartItem>>>()
    val cartResult: LiveData<Result<List<CartItem>>> = _cartResult

    private var _currentSlug = ""

    fun isWishlisted(id: String): LiveData<Boolean> = wishlistRepo.isWishlisted(id).asLiveData()

    fun loadProduct(slug: String) {
        _currentSlug = slug
        viewModelScope.launch {
            _product.value = Result.Loading
            _product.value = productRepo.getProduct(slug)
        }
    }

    fun addToCart(productId: String, quantity: Int = 1) = viewModelScope.launch {
        _cartResult.value = Result.Loading
        _cartResult.value = cartRepo.addToCart(productId, quantity)
    }

    fun toggleWishlist(product: Product) = viewModelScope.launch {
        wishlistRepo.toggle(product)
    }
}

// ── Cart ViewModel ────────────────────────────────────────────

@HiltViewModel
class CartViewModel @Inject constructor(
    private val cartRepo: CartRepository
) : ViewModel() {

    private val _cart = MutableLiveData<Result<List<CartItem>>>()
    val cart: LiveData<Result<List<CartItem>>> = _cart

    val cartCount: LiveData<Int> = cartRepo.cartCount.asLiveData()

    init { loadCart() }

    fun loadCart() = viewModelScope.launch {
        _cart.value = Result.Loading
        _cart.value = cartRepo.getCart()
    }

    fun updateItem(id: String, quantity: Int) = viewModelScope.launch {
        val result = cartRepo.updateItem(id, quantity)
        if (result is Result.Success) _cart.value = Result.Success(result.data)
    }

    fun removeItem(id: String) = viewModelScope.launch {
        val result = cartRepo.removeItem(id)
        if (result is Result.Success) _cart.value = Result.Success(result.data)
    }

    fun getTotal(items: List<CartItem>): Double =
        items.sumOf { it.unitPrice.moneyValue() * it.quantity }
}

// ── Wishlist ViewModel ────────────────────────────────────────

@HiltViewModel
class WishlistViewModel @Inject constructor(
    private val wishlistRepo: WishlistRepository,
    private val cartRepo: CartRepository
) : ViewModel() {

    val wishlist: LiveData<List<WishlistEntity>> = wishlistRepo.getAll().asLiveData()

    private val _cartResult = MutableLiveData<Result<List<CartItem>>?>()
    val cartResult: LiveData<Result<List<CartItem>>?> = _cartResult

    fun removeFromWishlist(productId: String) = viewModelScope.launch {
        wishlistRepo.remove(productId)
    }

    fun addToCart(productId: String) = viewModelScope.launch {
        _cartResult.value = cartRepo.addToCart(productId)
    }
}

// ── Checkout ViewModel ────────────────────────────────────────

@HiltViewModel
class CheckoutViewModel @Inject constructor(
    private val orderRepo: OrderRepository,
    private val cartRepo: CartRepository
) : ViewModel() {

    private val _order = MutableLiveData<Result<Order>>()
    val order: LiveData<Result<Order>> = _order

    fun checkout(
        fullName: String, phone: String, country: String,
        city: String, street: String, postal: String
    ) = viewModelScope.launch {
        _order.value = Result.Loading
        val result = orderRepo.checkout(
            CheckoutRequest(
                shippingAddress = ShippingAddress(fullName, phone, country, city, street, postal)
            )
        )
        if (result is Result.Success) cartRepo.clearCart()
        _order.value = result
    }
}

// ── Orders ViewModel ──────────────────────────────────────────

@HiltViewModel
class OrdersViewModel @Inject constructor(
    private val repo: OrderRepository
) : ViewModel() {

    private val _orders = MutableLiveData<Result<List<Order>>>()
    val orders: LiveData<Result<List<Order>>> = _orders

    private val _order = MutableLiveData<Result<Order>>()
    val order: LiveData<Result<Order>> = _order

    init { loadOrders() }

    fun loadOrders() = viewModelScope.launch {
        _orders.value = Result.Loading
        _orders.value = repo.getOrders()
    }

    fun loadOrder(id: String) = viewModelScope.launch {
        _order.value = Result.Loading
        _order.value = repo.getOrder(id)
    }
}

// ── Recommendations ViewModel ─────────────────────────────────

@HiltViewModel
class RecommendationsViewModel @Inject constructor(
    private val repo: RecommendationRepository,
    private val cartRepo: CartRepository,
    private val wishlistRepo: WishlistRepository
) : ViewModel() {

    private val _recs = MutableLiveData<Result<List<Recommendation>>>()
    val recommendations: LiveData<Result<List<Recommendation>>> = _recs

    private val _cartResult = MutableLiveData<Result<List<CartItem>>?>()
    val cartResult: LiveData<Result<List<CartItem>>?> = _cartResult

    init { load() }

    fun load() = viewModelScope.launch {
        _recs.value = Result.Loading
        _recs.value = repo.getRecommendations()
    }

    fun addToCart(productId: String) = viewModelScope.launch {
        _cartResult.value = cartRepo.addToCart(productId)
    }
}
