package com.novashop.ui

import android.graphics.Paint
import android.view.*
import androidx.recyclerview.widget.*
import com.novashop.R
import com.novashop.data.api.*
import com.novashop.data.db.WishlistEntity
import com.novashop.databinding.*

private fun String.moneyValue(): Double =
    filter { it.isDigit() || it == '.' || it == '-' }.toDoubleOrNull() ?: 0.0

// ── Product Adapter ───────────────────────────────────────────

class ProductAdapter(
    private val onProductClick: (Product) -> Unit,
    private val onWishlistClick: (Product) -> Unit,
    private var wishlistedIds: Set<String>
) : ListAdapter<Product, ProductAdapter.VH>(ProductDiff()) {

    fun updateWishlist(ids: Set<String>) {
        wishlistedIds = ids
        notifyDataSetChanged()
    }

    inner class VH(val b: ItemProductBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemProductBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val product = getItem(position)
        with(holder.b) {
            tvName.text     = product.name
            tvPrice.text    = formatPrice(product.price.toDoubleOrNull() ?: 0.0)
            tvCategory.text = product.categoryName ?: ""

            product.comparePrice?.let { cp ->
                tvComparePrice.visibility = View.VISIBLE
                tvComparePrice.text       = formatPrice(cp.toDoubleOrNull() ?: 0.0)
                tvComparePrice.paintFlags = tvComparePrice.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
                val comparePrice = cp.moneyValue()
                val currentPrice = product.price.moneyValue()
                val disc = if (comparePrice > 0) {
                    ((1 - (currentPrice / comparePrice)) * 100).toInt()
                } else 0
                tvDiscount.visibility = View.VISIBLE
                tvDiscount.text       = "-$disc%"
            } ?: run {
                tvComparePrice.visibility = View.GONE
                tvComparePrice.paintFlags = tvComparePrice.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
                tvDiscount.visibility     = View.GONE
            }

            loadImage(ivProduct, product.imageUrls.firstOrNull() ?: "")

            btnWishlist.setImageResource(
                if (product.id in wishlistedIds) R.drawable.ic_heart_filled
                else R.drawable.ic_heart_outline
            )

            tvOutOfStock.visibility = if (product.stockQty == 0) View.VISIBLE else View.GONE

            root.setOnClickListener        { onProductClick(product) }
            btnWishlist.setOnClickListener { onWishlistClick(product) }
        }
    }

    class ProductDiff : DiffUtil.ItemCallback<Product>() {
        override fun areItemsTheSame(a: Product, b: Product) = a.id == b.id
        override fun areContentsTheSame(a: Product, b: Product) = a == b
    }
}

// ── Cart Adapter ──────────────────────────────────────────────

class CartAdapter(
    private val onQtyChange: (CartItem, Int) -> Unit,
    private val onRemove: (CartItem) -> Unit
) : ListAdapter<CartItem, CartAdapter.VH>(CartDiff()) {

    inner class VH(val b: ItemCartBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemCartBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = getItem(position)
        with(holder.b) {
            tvName.text     = item.name
            tvPrice.text    = formatPrice(item.unitPrice.moneyValue() * item.quantity)
            tvQuantity.text = item.quantity.toString()
            tvUnitPrice.text = formatPrice(item.unitPrice.moneyValue())

            loadImage(ivProduct, item.imageUrls.firstOrNull() ?: "")

            btnMinus.setOnClickListener {
                if (item.quantity > 1) onQtyChange(item, item.quantity - 1)
                else onRemove(item)
            }
            btnPlus.setOnClickListener {
                if (item.quantity < item.stockQty) onQtyChange(item, item.quantity + 1)
            }
            btnRemove.setOnClickListener { onRemove(item) }
        }
    }

    class CartDiff : DiffUtil.ItemCallback<CartItem>() {
        override fun areItemsTheSame(a: CartItem, b: CartItem) = a.id == b.id
        override fun areContentsTheSame(a: CartItem, b: CartItem) = a == b
    }
}

// ── Wishlist Adapter ──────────────────────────────────────────

class WishlistAdapter(
    private val onRemove: (WishlistEntity) -> Unit,
    private val onAddToCart: (WishlistEntity) -> Unit,
    private val onItemClick: (WishlistEntity) -> Unit
) : ListAdapter<WishlistEntity, WishlistAdapter.VH>(WishlistDiff()) {

    inner class VH(val b: ItemWishlistBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemWishlistBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = getItem(position)
        with(holder.b) {
            tvName.text  = item.name
            tvPrice.text = formatPrice(item.price.toDoubleOrNull() ?: 0.0)
            loadImage(ivProduct, item.imageUrl)
            root.setOnClickListener        { onItemClick(item) }
            btnRemove.setOnClickListener   { onRemove(item) }
            btnAddToCart.setOnClickListener { onAddToCart(item) }
        }
    }

    class WishlistDiff : DiffUtil.ItemCallback<WishlistEntity>() {
        override fun areItemsTheSame(a: WishlistEntity, b: WishlistEntity) = a.productId == b.productId
        override fun areContentsTheSame(a: WishlistEntity, b: WishlistEntity) = a == b
    }
}

// ── Orders Adapter ────────────────────────────────────────────

class OrdersAdapter(
    private val onClick: (Order) -> Unit
) : ListAdapter<Order, OrdersAdapter.VH>(OrderDiff()) {

    inner class VH(val b: ItemOrderBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemOrderBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val order = getItem(position)
        with(holder.b) {
            tvOrderId.text = "#${order.id.take(8).uppercase()}"
            tvStatus.text  = statusLabel(order.status)
            tvTotal.text   = formatPrice(order.totalAmount.toDoubleOrNull() ?: 0.0)
            tvDate.text    = formatDate(order.createdAt)
            tvItems.text   = "${order.items.size} items"
            tvStatus.setBackgroundResource(statusColor(order.status))
            root.setOnClickListener { onClick(order) }
        }
    }

    class OrderDiff : DiffUtil.ItemCallback<Order>() {
        override fun areItemsTheSame(a: Order, b: Order) = a.id == b.id
        override fun areContentsTheSame(a: Order, b: Order) = a == b
    }
}

// ── Order Items Adapter ───────────────────────────────────────

class OrderItemsAdapter : ListAdapter<OrderItem, OrderItemsAdapter.VH>(OrderItemDiff()) {
    inner class VH(val b: ItemOrderItemBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemOrderItemBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, pos: Int) {
        val item = getItem(pos)
        with(holder.b) {
            tvName.text  = item.productName
            tvQty.text   = "x${item.quantity}"
            tvPrice.text = formatPrice(item.totalPrice.toDoubleOrNull() ?: 0.0)
            tvSku.text   = item.sku ?: ""
        }
    }

    class OrderItemDiff : DiffUtil.ItemCallback<OrderItem>() {
        override fun areItemsTheSame(a: OrderItem, b: OrderItem) = a.id == b.id
        override fun areContentsTheSame(a: OrderItem, b: OrderItem) = a == b
    }
}

// ── Status History Adapter ────────────────────────────────────

class StatusHistoryAdapter : ListAdapter<StatusHistory, StatusHistoryAdapter.VH>(HistoryDiff()) {
    inner class VH(val b: ItemStatusHistoryBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemStatusHistoryBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, pos: Int) {
        val h = getItem(pos)
        with(holder.b) {
            tvStatus.text = statusLabel(h.status)
            tvDate.text   = formatDate(h.at)
            tvComment.text   = h.comment ?: ""
            tvComment.visibility = if (h.comment.isNullOrEmpty()) View.GONE else View.VISIBLE
            tvStatus.setBackgroundResource(statusColor(h.status))
        }
    }

    class HistoryDiff : DiffUtil.ItemCallback<StatusHistory>() {
        override fun areItemsTheSame(a: StatusHistory, b: StatusHistory) = a.at == b.at
        override fun areContentsTheSame(a: StatusHistory, b: StatusHistory) = a == b
    }
}

// ── Recommendations Adapter ───────────────────────────────────

class RecommendationsAdapter(
    private val onItemClick: (Recommendation) -> Unit,
    private val onAddToCart: (Recommendation) -> Unit
) : ListAdapter<Recommendation, RecommendationsAdapter.VH>(RecsDiff()) {
    inner class VH(val b: ItemRecommendationBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemRecommendationBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, pos: Int) {
        val rec = getItem(pos)
        with(holder.b) {
            tvName.text  = rec.name
            tvPrice.text = formatPrice(rec.price.toDoubleOrNull() ?: 0.0)
            loadImage(ivProduct, rec.imageUrls.firstOrNull() ?: "")
            root.setOnClickListener         { onItemClick(rec) }
            btnAddToCart.setOnClickListener { onAddToCart(rec) }
        }
    }

    class RecsDiff : DiffUtil.ItemCallback<Recommendation>() {
        override fun areItemsTheSame(a: Recommendation, b: Recommendation) = a.id == b.id
        override fun areContentsTheSame(a: Recommendation, b: Recommendation) = a == b
    }
}
