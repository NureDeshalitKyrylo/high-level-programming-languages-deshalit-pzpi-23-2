package com.novashop.ui

import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.core.os.bundleOf
import androidx.core.widget.addTextChangedListener
import androidx.fragment.app.*
import androidx.navigation.navOptions
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.*
import coil.load
import com.novashop.BuildConfig
import com.novashop.R
import com.novashop.data.api.*
import com.novashop.data.db.WishlistEntity
import com.novashop.data.repository.Result
import com.novashop.databinding.*
import com.google.android.material.chip.Chip
import com.google.android.material.snackbar.Snackbar
import dagger.hilt.android.AndroidEntryPoint
import java.text.NumberFormat
import java.util.*

// ═══════════════════════════════════════════════════════════════
// LOGIN FRAGMENT
// ═══════════════════════════════════════════════════════════════

@AndroidEntryPoint
class LoginFragment : Fragment(R.layout.fragment_login) {
    private val vm: AuthViewModel by activityViewModels()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val b = FragmentLoginBinding.bind(view)

        b.btnLogin.setOnClickListener {
            val email = b.etEmail.text.toString().trim()
            val pass  = b.etPassword.text.toString()
            if (email.isEmpty() || pass.isEmpty()) {
                Snackbar.make(view, "Fill in all fields", Snackbar.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            vm.login(email, pass)
        }

        b.tvRegister.setOnClickListener {
            findNavController().navigate(R.id.action_login_to_register)
        }

        vm.state.observe(viewLifecycleOwner) { result ->
            b.progressBar.visibility = if (result is Result.Loading) View.VISIBLE else View.GONE
            when (result) {
                is Result.Success -> findNavController().navigate(R.id.action_login_to_catalog)
                is Result.Error   -> Snackbar.make(view, result.message, Snackbar.LENGTH_LONG).show()
                else -> {}
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// REGISTER FRAGMENT
// ═══════════════════════════════════════════════════════════════

@AndroidEntryPoint
class RegisterFragment : Fragment(R.layout.fragment_register) {
    private val vm: AuthViewModel by activityViewModels()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val b = FragmentRegisterBinding.bind(view)

        b.btnRegister.setOnClickListener {
            val name  = b.etName.text.toString().trim()
            val email = b.etEmail.text.toString().trim()
            val pass  = b.etPassword.text.toString()
            if (name.isEmpty() || email.isEmpty() || pass.isEmpty()) {
                Snackbar.make(view, "Fill in all fields", Snackbar.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            vm.register(email, pass, name)
        }

        b.tvLogin.setOnClickListener { findNavController().navigateUp() }

        vm.state.observe(viewLifecycleOwner) { result ->
            b.progressBar.visibility = if (result is Result.Loading) View.VISIBLE else View.GONE
            when (result) {
                is Result.Success -> findNavController().navigate(R.id.action_register_to_catalog)
                is Result.Error   -> Snackbar.make(view, result.message, Snackbar.LENGTH_LONG).show()
                else -> {}
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// CATALOG FRAGMENT
// ═══════════════════════════════════════════════════════════════

@AndroidEntryPoint
class CatalogFragment : Fragment(R.layout.fragment_catalog) {
    private val vm: CatalogViewModel by viewModels()
    private lateinit var adapter: ProductAdapter

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val b = FragmentCatalogBinding.bind(view)

        adapter = ProductAdapter(
            onProductClick   = { product ->
                findNavController().navigate(
                    R.id.action_catalog_to_detail,
                    bundleOf("slug" to product.slug)
                )
            },
            onWishlistClick  = { product -> vm.toggleWishlist(product) },
            wishlistedIds    = emptySet()
        )

        b.recyclerView.apply {
            layoutManager = GridLayoutManager(requireContext(), 2)
            adapter       = this@CatalogFragment.adapter
            setHasFixedSize(true)
        }

        b.swipeRefresh.setOnRefreshListener {
            vm.loadProducts()
            b.swipeRefresh.isRefreshing = false
        }

        // Search
        b.etSearch.addTextChangedListener {
            vm.searchQuery = it.toString()
            vm.loadProducts()
        }

        // Pagination
        b.btnPrev.setOnClickListener { vm.prevPage() }
        b.btnNext.setOnClickListener { vm.nextPage() }

        vm.products.observe(viewLifecycleOwner) { result ->
            b.progressBar.visibility = if (result is Result.Loading) View.VISIBLE else View.GONE
            b.shimmerLayout.apply {
                if (result is Result.Loading) { visibility = View.VISIBLE; startShimmer() }
                else { stopShimmer(); visibility = View.GONE }
            }
            when (result) {
                is Result.Success -> {
                    adapter.submitList(result.data.items)
                    b.tvPage.text = "Page ${vm.currentPage} / ${vm.totalPages}"
                    b.btnPrev.isEnabled = vm.currentPage > 1
                    b.btnNext.isEnabled = vm.currentPage < vm.totalPages
                }
                is Result.Error -> Snackbar.make(view, result.message, Snackbar.LENGTH_LONG).show()
                else -> {}
            }
        }

        vm.categories.observe(viewLifecycleOwner) { result ->
            if (result is Result.Success) {
                b.chipGroupCategories.removeAllViews()
                val allChip = Chip(requireContext()).apply {
                    text = "All"; isCheckable = true; isChecked = true
                    setOnClickListener { vm.selectedCategory = ""; vm.loadProducts() }
                }
                b.chipGroupCategories.addView(allChip)
                result.data.filter { it.id < 6 }.forEach { cat ->
                    val chip = Chip(requireContext()).apply {
                        text = cat.name; isCheckable = true
                        setOnClickListener { vm.selectedCategory = cat.slug; vm.loadProducts() }
                    }
                    b.chipGroupCategories.addView(chip)
                }
            }
        }

        vm.wishlistIds.observe(viewLifecycleOwner) { ids ->
            adapter.updateWishlist(ids)
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// PRODUCT DETAIL FRAGMENT
// ═══════════════════════════════════════════════════════════════

@AndroidEntryPoint
class ProductDetailFragment : Fragment(R.layout.fragment_product_detail) {
    private val vm: ProductDetailViewModel by viewModels()
    private var currentImageIndex = 0

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val b    = FragmentProductDetailBinding.bind(view)
        val slug = arguments?.getString("slug") ?: return

        vm.loadProduct(slug)

        b.toolbar.setNavigationOnClickListener { findNavController().navigateUp() }

        vm.product.observe(viewLifecycleOwner) { result ->
            b.progressBar.visibility = if (result is Result.Loading) View.VISIBLE else View.GONE
            if (result is Result.Success) {
                val p = result.data
                b.tvName.text     = p.name
                b.tvCategory.text = p.categoryName
                b.tvPrice.text    = formatPrice(p.price.toDoubleOrNull() ?: 0.0)
                b.tvDescription.text = p.description ?: ""
                b.tvStock.text    = if (p.stockQty > 0) "In stock: ${p.stockQty}" else "Out of stock"
                b.btnAddToCart.isEnabled = p.stockQty > 0

                // Images
                if (p.imageUrls.isNotEmpty()) {
                    loadImage(b.ivProduct, p.imageUrls[0])
                    if (p.imageUrls.size > 1) {
                        b.btnPrevImage.visibility = View.VISIBLE
                        b.btnNextImage.visibility = View.VISIBLE
                        b.btnNextImage.setOnClickListener {
                            currentImageIndex = (currentImageIndex + 1) % p.imageUrls.size
                            loadImage(b.ivProduct, p.imageUrls[currentImageIndex])
                        }
                        b.btnPrevImage.setOnClickListener {
                            currentImageIndex = (currentImageIndex - 1 + p.imageUrls.size) % p.imageUrls.size
                            loadImage(b.ivProduct, p.imageUrls[currentImageIndex])
                        }
                    }
                }

                // Tags
                b.chipGroupTags.removeAllViews()
                (p.tags as? List<*>)?.forEach { tag ->
                    val tagStr = when (tag) {
                        is String -> tag
                        is Map<*, *> -> tag["slug"] as? String ?: tag["name"] as? String ?: ""
                        else -> ""
                    }
                    if (tagStr.isNotEmpty()) {
                        b.chipGroupTags.addView(Chip(requireContext()).apply { text = "#$tagStr" })
                    }
                }

                // Quantity
                var qty = 1
                b.tvQuantity.text = "1"
                b.btnMinus.setOnClickListener { if (qty > 1) { qty--; b.tvQuantity.text = qty.toString() } }
                b.btnPlus.setOnClickListener  { if (qty < p.stockQty) { qty++; b.tvQuantity.text = qty.toString() } }

                b.btnAddToCart.setOnClickListener { vm.addToCart(p.id, qty) }

                b.btnWishlist.setOnClickListener { vm.toggleWishlist(p) }

                // Wishlist state
                vm.isWishlisted(p.id).observe(viewLifecycleOwner) { isWl ->
                    b.btnWishlist.setImageResource(
                        if (isWl) R.drawable.ic_heart_filled else R.drawable.ic_heart_outline
                    )
                }

                // Rating
                if ((p.avgRating?.toDoubleOrNull() ?: 0.0) > 0) {
                    b.ratingBar.rating = p.avgRating?.toFloat() ?: 0f
                    b.tvReviewCount.text = "(${p.reviewCount} reviews)"
                }
            }
        }

        vm.cartResult.observe(viewLifecycleOwner) { result ->
            when (result) {
                is Result.Success -> Snackbar.make(view, "Added to cart ✓", Snackbar.LENGTH_SHORT).show()
                is Result.Error   -> Snackbar.make(view, result.message, Snackbar.LENGTH_LONG).show()
                else -> {}
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// CART FRAGMENT
// ═══════════════════════════════════════════════════════════════

@AndroidEntryPoint
class CartFragment : Fragment(R.layout.fragment_cart) {
    private val vm: CartViewModel by viewModels()
    private val authVm: AuthViewModel by activityViewModels()
    private lateinit var adapter: CartAdapter

    override fun onStart() {
        super.onStart()
        vm.loadCart()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val b = FragmentCartBinding.bind(view)

        adapter = CartAdapter(
            onQtyChange = { item, qty -> vm.updateItem(item.id, qty) },
            onRemove    = { item -> vm.removeItem(item.id) }
        )
        b.recyclerView.layoutManager = LinearLayoutManager(requireContext())
        b.recyclerView.adapter = adapter

        b.btnCheckout.setOnClickListener {
            if (authVm.currentUser == null) {
                findNavController().navigate(R.id.action_cart_to_login)
            } else {
                findNavController().navigate(R.id.action_cart_to_checkout)
            }
        }

        vm.cart.observe(viewLifecycleOwner) { result ->
            b.progressBar.visibility = if (result is Result.Loading) View.VISIBLE else View.GONE
            when (result) {
                is Result.Success -> {
                    adapter.submitList(result.data)
                    val total = vm.getTotal(result.data)
                    b.tvTotal.text = "Total: ${formatPrice(total)}"
                    b.tvEmpty.visibility = if (result.data.isEmpty()) View.VISIBLE else View.GONE
                    b.btnCheckout.isEnabled = result.data.isNotEmpty()
                    val shipping = if (total > 100) 0.0 else 9.99
                    b.tvShipping.text = if (shipping == 0.0) "Shipping: Free" else "Shipping: ${formatPrice(shipping)}"
                    b.tvGrandTotal.text = "Grand total: ${formatPrice(total + shipping)}"
                }
                is Result.Error -> Snackbar.make(view, result.message, Snackbar.LENGTH_LONG).show()
                else -> {}
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// WISHLIST FRAGMENT
// ═══════════════════════════════════════════════════════════════

@AndroidEntryPoint
class WishlistFragment : Fragment(R.layout.fragment_wishlist) {
    private val vm: WishlistViewModel by viewModels()
    private lateinit var adapter: WishlistAdapter

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val b = FragmentWishlistBinding.bind(view)

        adapter = WishlistAdapter(
            onRemove    = { item -> vm.removeFromWishlist(item.productId) },
            onAddToCart = { item -> vm.addToCart(item.productId) },
            onItemClick = { item ->
                findNavController().navigate(
                    R.id.action_wishlist_to_detail,
                    bundleOf("slug" to item.slug)
                )
            }
        )
        b.recyclerView.layoutManager = LinearLayoutManager(requireContext())
        b.recyclerView.adapter = adapter

        vm.wishlist.observe(viewLifecycleOwner) { list ->
            adapter.submitList(list)
            b.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        }

        vm.cartResult.observe(viewLifecycleOwner) { result ->
            if (result is Result.Success)
                Snackbar.make(view, "Added to cart ✓", Snackbar.LENGTH_SHORT).show()
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// CHECKOUT FRAGMENT
// ═══════════════════════════════════════════════════════════════

@AndroidEntryPoint
class CheckoutFragment : Fragment(R.layout.fragment_checkout) {
    private val vm: CheckoutViewModel by viewModels()
    private val authVm: AuthViewModel by activityViewModels()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val b = FragmentCheckoutBinding.bind(view)
        b.toolbar.setNavigationOnClickListener { findNavController().navigateUp() }

        // Pre-fill name
        authVm.currentUser?.fullName?.let { b.etFullName.setText(it) }
        b.etCountry.setText("Ukraine")

        b.btnConfirm.setOnClickListener {
            val name    = b.etFullName.text.toString().trim()
            val phone   = b.etPhone.text.toString().trim()
            val country = b.etCountry.text.toString().trim()
            val city    = b.etCity.text.toString().trim()
            val street  = b.etStreet.text.toString().trim()
            val postal  = b.etPostal.text.toString().trim()

            if (name.isEmpty() || city.isEmpty() || street.isEmpty()) {
                Snackbar.make(view, "Fill required fields", Snackbar.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            vm.checkout(name, phone, country, city, street, postal)
        }

        vm.order.observe(viewLifecycleOwner) { result ->
            b.progressBar.visibility = if (result is Result.Loading) View.VISIBLE else View.GONE
            b.btnConfirm.isEnabled   = result !is Result.Loading
            when (result) {
                is Result.Success -> {
                    val orderId = result.data.id.trim()
                    if (orderId.isEmpty()) {
                        Snackbar.make(view, "Order created, but no order ID was returned", Snackbar.LENGTH_LONG).show()
                        return@observe
                    }
                    findNavController().navigate(
                        R.id.action_checkout_to_orderDetail,
                        bundleOf("orderId" to orderId),
                        navOptions {
                            popUpTo(R.id.checkoutFragment) {
                                inclusive = true
                            }
                        }
                    )
                }
                is Result.Error -> Snackbar.make(view, result.message, Snackbar.LENGTH_LONG).show()
                else -> {}
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// ORDERS LIST FRAGMENT
// ═══════════════════════════════════════════════════════════════

@AndroidEntryPoint
class OrdersFragment : Fragment(R.layout.fragment_orders) {
    private val vm: OrdersViewModel by viewModels()
    private val authVm: AuthViewModel by activityViewModels()
    private lateinit var adapter: OrdersAdapter

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val b = FragmentOrdersBinding.bind(view)

        adapter = OrdersAdapter { order ->
            findNavController().navigate(
                R.id.action_orders_to_detail,
                bundleOf("orderId" to order.id)
            )
        }
        b.recyclerView.layoutManager = LinearLayoutManager(requireContext())
        b.recyclerView.adapter = adapter

        b.swipeRefresh.setOnRefreshListener {
            vm.loadOrders()
            b.swipeRefresh.isRefreshing = false
        }

        authVm.isLoggedIn.observe(viewLifecycleOwner) { loggedIn ->
            if (!loggedIn) {
                b.tvEmpty.text    = "Login to see your orders"
                b.tvEmpty.visibility = View.VISIBLE
                b.btnLogin.visibility = View.VISIBLE
                b.btnLogin.setOnClickListener {
                    findNavController().navigate(R.id.action_orders_to_login)
                }
            } else {
                b.btnLogin.visibility = View.GONE
                vm.loadOrders()
            }
        }

        vm.orders.observe(viewLifecycleOwner) { result ->
            b.progressBar.visibility = if (result is Result.Loading) View.VISIBLE else View.GONE
            when (result) {
                is Result.Success -> {
                    adapter.submitList(result.data)
                    b.tvEmpty.visibility = if (result.data.isEmpty()) View.VISIBLE else View.GONE
                }
                is Result.Error -> Snackbar.make(view, result.message, Snackbar.LENGTH_LONG).show()
                else -> {}
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// ORDER DETAIL FRAGMENT
// ═══════════════════════════════════════════════════════════════

@AndroidEntryPoint
class OrderDetailFragment : Fragment(R.layout.fragment_order_detail) {
    private val vm: OrdersViewModel by viewModels()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val b       = FragmentOrderDetailBinding.bind(view)
        val orderId = arguments?.getString("orderId") ?: return

        b.toolbar.setNavigationOnClickListener { findNavController().navigateUp() }
        vm.loadOrder(orderId)

        vm.order.observe(viewLifecycleOwner) { result ->
            b.progressBar.visibility = if (result is Result.Loading) View.VISIBLE else View.GONE
            if (result is Result.Success) {
                val o = result.data
                b.tvOrderId.text     = "Order #${o.id.take(8).uppercase()}"
                b.tvStatus.text      = statusLabel(o.status)
                b.tvStatus.setBackgroundResource(statusColor(o.status))
                b.tvDate.text        = formatDate(o.createdAt)
                b.tvTotal.text       = formatPrice(o.totalAmount.toDoubleOrNull() ?: 0.0)
                b.tvAddress.text     = "${o.shipFullName}\n${o.shipStreet}\n${o.shipCity}, ${o.shipCountry}"

                // Progress bar steps
                val steps = listOf("pending","confirmed","processing","shipped","delivered")
                val stepIdx = steps.indexOf(o.status)
                b.progressStepper.apply {
                    if (o.status !in listOf("cancelled", "refunded")) {
                        visibility = View.VISIBLE
                        progress   = ((stepIdx + 1) * 100 / steps.size)
                    } else visibility = View.GONE
                }

                // Items
                val itemsAdapter = OrderItemsAdapter()
                b.rvItems.layoutManager = LinearLayoutManager(requireContext())
                b.rvItems.adapter       = itemsAdapter
                itemsAdapter.submitList(o.items)

                // Status history
                if (o.history.isNotEmpty()) {
                    val historyAdapter = StatusHistoryAdapter()
                    b.rvHistory.layoutManager = LinearLayoutManager(requireContext())
                    b.rvHistory.adapter       = historyAdapter
                    historyAdapter.submitList(o.history)
                    b.tvHistoryTitle.visibility = View.VISIBLE
                }
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// PROFILE / RECOMMENDATIONS FRAGMENT
// ═══════════════════════════════════════════════════════════════

@AndroidEntryPoint
class ProfileFragment : Fragment(R.layout.fragment_profile) {
    private val authVm: AuthViewModel by activityViewModels()
    private val recsVm: RecommendationsViewModel by viewModels()
    private lateinit var recsAdapter: RecommendationsAdapter

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val b = FragmentProfileBinding.bind(view)

        recsAdapter = RecommendationsAdapter(
            onItemClick = { rec ->
                findNavController().navigate(
                    R.id.action_profile_to_detail,
                    bundleOf("slug" to rec.slug)
                )
            },
            onAddToCart = { rec -> recsVm.addToCart(rec.id) }
        )
        b.rvRecommendations.layoutManager =
            LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        b.rvRecommendations.adapter = recsAdapter

        authVm.isLoggedIn.observe(viewLifecycleOwner) { loggedIn ->
            if (loggedIn) {
                val user = authVm.currentUser
                b.tvName.text  = user?.fullName ?: user?.email ?: "User"
                b.tvEmail.text = user?.email ?: ""
                b.tvRole.text  = user?.role?.uppercase()
                b.cardLoggedIn.visibility  = View.VISIBLE
                b.cardLoggedOut.visibility = View.GONE
                b.sectionRecs.visibility   = View.VISIBLE
                recsVm.load()
            } else {
                b.cardLoggedIn.visibility  = View.GONE
                b.cardLoggedOut.visibility = View.VISIBLE
                b.sectionRecs.visibility   = View.GONE
            }
        }

        b.btnLogout.setOnClickListener { authVm.logout() }

        b.btnLogin.setOnClickListener {
            findNavController().navigate(R.id.action_profile_to_login)
        }

        recsVm.recommendations.observe(viewLifecycleOwner) { result ->
            b.recsProgress.visibility = if (result is Result.Loading) View.VISIBLE else View.GONE
            if (result is Result.Success) recsAdapter.submitList(result.data)
        }

        recsVm.cartResult.observe(viewLifecycleOwner) { result ->
            if (result is Result.Success)
                Snackbar.make(view, "Added to cart ✓", Snackbar.LENGTH_SHORT).show()
        }
    }
}

// ═══════════════════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════════════════

fun formatPrice(amount: Double): String =
    NumberFormat.getCurrencyInstance(Locale.US).format(amount)

fun formatDate(iso: String): String = try {
    val sdf  = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault())
    val date = sdf.parse(iso.substringBefore("."))
    java.text.SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(date!!)
} catch (_: Exception) { iso }

fun statusLabel(status: String) = when (status) {
    "pending"    -> "Pending"
    "confirmed"  -> "Confirmed"
    "processing" -> "Processing"
    "shipped"    -> "Shipped"
    "delivered"  -> "Delivered"
    "cancelled"  -> "Cancelled"
    "refunded"   -> "Refunded"
    else         -> status
}

fun statusColor(status: String) = when (status) {
    "delivered" -> R.drawable.badge_success
    "shipped"   -> R.drawable.badge_info
    "cancelled","refunded" -> R.drawable.badge_error
    else        -> R.drawable.badge_warning
}

private fun normalizeImageUrl(url: String): String? {
    val trimmed = url.trim()
    if (trimmed.isEmpty()) return null
    if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) return trimmed

    val base = BuildConfig.BASE_URL.substringBefore("/api/")
    return if (trimmed.startsWith("/")) base + trimmed else "$base/$trimmed"
}

fun loadImage(imageView: android.widget.ImageView, url: String) {
    imageView.load(normalizeImageUrl(url)) {
        crossfade(true)
        placeholder(R.drawable.placeholder_product)
        error(R.drawable.placeholder_product)
    }
}
