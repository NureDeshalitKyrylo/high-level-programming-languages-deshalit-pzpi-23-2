package com.novashop.data.api

import com.google.gson.annotations.SerializedName
import com.google.gson.*
import java.lang.reflect.Type

// ── Auth ─────────────────────────────────────────────────────

data class LoginRequest(val email: String, val password: String)

data class RegisterRequest(
    val email: String,
    val password: String,
    val full_name: String
)

data class AuthResponse(
    val user: User,
    @SerializedName("accessToken")  val accessToken: String,
    @SerializedName("refreshToken") val refreshToken: String
)

data class RefreshRequest(@SerializedName("refreshToken") val refreshToken: String)

data class RefreshResponse(
    @SerializedName("accessToken")  val accessToken: String,
    @SerializedName("refreshToken") val refreshToken: String
)

data class User(
    val id: String,
    val email: String,
    @SerializedName("full_name") val fullName: String?,
    val role: String,
    @SerializedName("avatar_url") val avatarUrl: String?
)

// ── Products ─────────────────────────────────────────────────

data class Product(
    val id: String,
    val sku: String,
    val name: String,
    val slug: String,
    val description: String?,
    val price: String,
    @SerializedName("compare_price") val comparePrice: String?,
    @SerializedName("stock_qty") val stockQty: Int,
    @SerializedName("is_featured") val isFeatured: Boolean,
    @SerializedName("image_urls") val imageUrls: List<String>,
    @SerializedName("category_name") val categoryName: String?,
    @SerializedName("category_slug") val categorySlug: String?,
    val tags: List<String> = emptyList(),
    @SerializedName("avg_rating") val avgRating: String?,
    @SerializedName("review_count") val reviewCount: String?,
    var isWishlisted: Boolean = false
)

data class ProductsResponse(
    val items: List<Product>,
    val total: Int,
    val page: Int,
    val limit: Int
)

data class Category(
    val id: Int,
    val name: String,
    val slug: String,
    @SerializedName("product_count") val productCount: Int
)

// ── Cart ─────────────────────────────────────────────────────

data class CartItem(
    val id: String,
    @SerializedName("product_id") val productId: String,
    val quantity: Int,
    @SerializedName("unit_price") val unitPrice: String,
    val name: String,
    val slug: String,
    @SerializedName("stock_qty") val stockQty: Int,
    @SerializedName("image_urls") val imageUrls: List<String>,
    @SerializedName("current_price") val currentPrice: String
)

data class AddToCartRequest(
    @SerializedName("product_id") val productId: String,
    val quantity: Int = 1
)

data class UpdateCartRequest(val quantity: Int)

// ── Orders ────────────────────────────────────────────────────

data class Order(
    val id: String,
    val status: String,
    @SerializedName("total_amount") val totalAmount: String,
    @SerializedName("shipping_amount") val shippingAmount: String,
    @SerializedName("created_at") val createdAt: String,
    @SerializedName("ship_full_name") val shipFullName: String?,
    @SerializedName("ship_city") val shipCity: String?,
    @SerializedName("ship_country") val shipCountry: String?,
    @SerializedName("ship_street") val shipStreet: String?,
    @SerializedName("payment_method") val paymentMethod: String?,
    val items: List<OrderItem> = emptyList(),
    val history: List<StatusHistory> = emptyList()
)

data class OrderItem(
    val id: String,
    @SerializedName("product_id") val productId: String?,
    @SerializedName("product_name") val productName: String,
    val sku: String?,
    val quantity: Int,
    @SerializedName("unit_price") val unitPrice: String,
    @SerializedName("total_price") val totalPrice: String
)

data class StatusHistory(
    val status: String,
    val at: String,
    val comment: String?
)

private fun JsonObject.objectValue(vararg names: String): JsonObject? {
    for (name in names) {
        val element = get(name) ?: continue
        if (element.isJsonNull) continue
        if (element.isJsonObject) return element.asJsonObject
    }
    return null
}

private fun JsonObject.arrayValue(vararg names: String): JsonElement? {
    for (name in names) {
        val element = get(name) ?: continue
        if (!element.isJsonNull) return element
    }
    return null
}

data class ShippingAddress(
    @SerializedName("full_name") val fullName: String,
    val phone: String,
    val country: String,
    val city: String,
    val street: String,
    val postal: String
)

data class CheckoutRequest(
    @SerializedName("shipping_address") val shippingAddress: ShippingAddress,
    @SerializedName("payment_method") val paymentMethod: String = "card"
)

// ── Recommendations ──────────────────────────────────────────

data class Recommendation(
    val id: String,
    val name: String,
    val slug: String,
    val price: String,
    @SerializedName("image_urls") val imageUrls: List<String>,
    @SerializedName("relevance_score") val relevanceScore: Double?
)

private fun JsonObject.string(vararg names: String): String? {
    for (name in names) {
        val element = get(name) ?: continue
        if (element.isJsonNull) continue
        return when {
            element.isJsonPrimitive -> element.asString
            else -> element.toString()
        }
    }
    return null
}

private fun JsonObject.int(vararg names: String): Int {
    for (name in names) {
        val element = get(name) ?: continue
        if (element.isJsonNull) continue
        return when {
            element.isJsonPrimitive -> {
                val primitive = element.asJsonPrimitive
                when {
                    primitive.isNumber -> primitive.asInt
                    primitive.isString -> primitive.asString.toDoubleOrNull()?.toInt() ?: 0
                    else -> 0
                }
            }
            else -> element.toString().toDoubleOrNull()?.toInt() ?: 0
        }
    }
    return 0
}

private fun JsonElement?.stringList(): List<String> {
    if (this == null || isJsonNull) return emptyList()
    return when {
        isJsonArray -> asJsonArray.mapNotNull { item ->
            when {
                item.isJsonNull -> null
                item.isJsonPrimitive -> item.asString
                item.isJsonObject -> item.asJsonObject.string("url", "image_url", "imageUrl", "path")
                else -> item.toString()
            }
        }
        isJsonPrimitive -> listOf(asString)
        else -> emptyList()
    }
}

private fun JsonObject.stringList(vararg names: String): List<String> {
    for (name in names) {
        val element = get(name) ?: continue
        val list = element.stringList()
        if (list.isNotEmpty()) return list
    }
    return emptyList()
}

object ProductDeserializer : JsonDeserializer<Product> {
    override fun deserialize(json: JsonElement, typeOfT: Type, context: JsonDeserializationContext): Product {
        val obj = json.asJsonObject
        return Product(
            id = obj.string("id", "_id") ?: "",
            sku = obj.string("sku") ?: "",
            name = obj.string("name") ?: "",
            slug = obj.string("slug") ?: "",
            description = obj.string("description"),
            price = obj.string("price", "current_price") ?: "0",
            comparePrice = obj.string("compare_price", "comparePrice"),
            stockQty = obj.int("stock_qty", "stockQty"),
            isFeatured = obj["is_featured"]?.asBoolean ?: obj["featured"]?.asBoolean ?: false,
            imageUrls = obj.stringList("image_urls", "images", "image_url", "imageUrl"),
            categoryName = obj.string("category_name", "categoryName"),
            categorySlug = obj.string("category_slug", "categorySlug"),
            tags = obj["tags"]?.stringList() ?: emptyList(),
            avgRating = obj.string("avg_rating", "avgRating"),
            reviewCount = obj.string("review_count", "reviewCount"),
            isWishlisted = obj["is_wishlisted"]?.asBoolean ?: obj["isWishlisted"]?.asBoolean ?: false
        )
    }
}

object CartItemDeserializer : JsonDeserializer<CartItem> {
    override fun deserialize(json: JsonElement, typeOfT: Type, context: JsonDeserializationContext): CartItem {
        val obj = json.asJsonObject
        return CartItem(
            id = obj.string("id", "_id") ?: "",
            productId = obj.string("product_id", "productId") ?: "",
            quantity = obj.int("quantity", "qty"),
            unitPrice = obj.string("unit_price", "unitPrice", "current_price", "currentPrice") ?: "0",
            name = obj.string("name") ?: "",
            slug = obj.string("slug") ?: "",
            stockQty = obj.int("stock_qty", "stockQty"),
            imageUrls = obj.stringList("image_urls", "images", "image_url", "imageUrl"),
            currentPrice = obj.string("current_price", "currentPrice", "unit_price", "unitPrice") ?: "0"
        )
    }
}

object RecommendationDeserializer : JsonDeserializer<Recommendation> {
    override fun deserialize(json: JsonElement, typeOfT: Type, context: JsonDeserializationContext): Recommendation {
        val obj = json.asJsonObject
        return Recommendation(
            id = obj.string("id", "_id") ?: "",
            name = obj.string("name") ?: "",
            slug = obj.string("slug") ?: "",
            price = obj.string("price", "current_price") ?: "0",
            imageUrls = obj.stringList("image_urls", "images", "image_url", "imageUrl"),
            relevanceScore = obj["relevance_score"]?.takeIf { !it.isJsonNull }?.asDouble
        )
    }
}

object OrderDeserializer : JsonDeserializer<Order> {
    override fun deserialize(json: JsonElement, typeOfT: Type, context: JsonDeserializationContext): Order {
        val root = json.asJsonObject.objectValue("order", "data") ?: json.asJsonObject
        val listType = object : com.google.gson.reflect.TypeToken<List<OrderItem>>() {}.type
        val historyType = object : com.google.gson.reflect.TypeToken<List<StatusHistory>>() {}.type

        val items = context.deserialize<List<OrderItem>>(
            root.arrayValue("items", "order_items", "orderItems") ?: JsonArray(),
            listType
        ) ?: emptyList()

        val history = context.deserialize<List<StatusHistory>>(
            root.arrayValue("history", "status_history", "statusHistory") ?: JsonArray(),
            historyType
        ) ?: emptyList()

        return Order(
            id = root.string("id", "_id", "order_id", "orderId") ?: "",
            status = root.string("status") ?: "pending",
            totalAmount = root.string("total_amount", "totalAmount", "total") ?: "0",
            shippingAmount = root.string("shipping_amount", "shippingAmount") ?: "0",
            createdAt = root.string("created_at", "createdAt") ?: "",
            shipFullName = root.string("ship_full_name", "shipFullName", "full_name"),
            shipCity = root.string("ship_city", "shipCity", "city"),
            shipCountry = root.string("ship_country", "shipCountry", "country"),
            shipStreet = root.string("ship_street", "shipStreet", "street"),
            paymentMethod = root.string("payment_method", "paymentMethod"),
            items = items,
            history = history
        )
    }
}
