package com.novashop.data.api

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "auth_prefs")

@Singleton
class TokenManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    companion object {
        val ACCESS_TOKEN  = stringPreferencesKey("access_token")
        val REFRESH_TOKEN = stringPreferencesKey("refresh_token")
        val USER_EMAIL    = stringPreferencesKey("user_email")
        val USER_NAME     = stringPreferencesKey("user_name")
        val USER_ROLE     = stringPreferencesKey("user_role")
        val USER_ID       = stringPreferencesKey("user_id")
    }

    val accessTokenFlow: Flow<String?> = context.dataStore.data.map { it[ACCESS_TOKEN] }
    val isLoggedIn: Flow<Boolean>      = context.dataStore.data.map { it[ACCESS_TOKEN] != null }

    suspend fun getAccessToken()  = context.dataStore.data.firstOrNull()?.get(ACCESS_TOKEN)
    suspend fun getRefreshToken() = context.dataStore.data.firstOrNull()?.get(REFRESH_TOKEN)

    suspend fun saveTokens(accessToken: String, refreshToken: String) {
        context.dataStore.edit {
            it[ACCESS_TOKEN]  = accessToken
            it[REFRESH_TOKEN] = refreshToken
        }
    }

    suspend fun saveUser(user: User) {
        context.dataStore.edit {
            it[USER_ID]    = user.id
            it[USER_EMAIL] = user.email
            it[USER_NAME]  = user.fullName ?: ""
            it[USER_ROLE]  = user.role
        }
    }

    suspend fun getUser(): User? {
        val prefs = context.dataStore.data.firstOrNull() ?: return null
        val id    = prefs[USER_ID] ?: return null
        return User(
            id        = id,
            email     = prefs[USER_EMAIL] ?: "",
            fullName  = prefs[USER_NAME],
            role      = prefs[USER_ROLE] ?: "customer",
            avatarUrl = null
        )
    }

    suspend fun clear() {
        context.dataStore.edit { it.clear() }
    }
}
