package com.novashop.ui

import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.novashop.R
import com.novashop.databinding.ActivityMainBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val authViewModel: AuthViewModel by viewModels()
    private val cartViewModel: CartViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val navHostFragment = supportFragmentManager
            .findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        val navController = navHostFragment.navController

        binding.bottomNav.setupWithNavController(navController)

        // Hide bottom nav on auth screens
        navController.addOnDestinationChangedListener { _, destination, _ ->
            val hideOn = setOf(R.id.loginFragment, R.id.registerFragment,
                R.id.productDetailFragment, R.id.checkoutFragment, R.id.orderDetailFragment)
            binding.bottomNav.visibility =
                if (destination.id in hideOn) View.GONE else View.VISIBLE
        }

        // Cart badge
        cartViewModel.cartCount.observe(this) { count ->
            val badge = binding.bottomNav.getOrCreateBadge(R.id.cartFragment)
            if (count > 0) { badge.isVisible = true; badge.number = count }
            else badge.isVisible = false
        }
    }
}
