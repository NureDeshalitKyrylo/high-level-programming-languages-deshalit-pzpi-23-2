package com.novashop.data.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

// ── Entities ─────────────────────────────────────────────────

@Entity(tableName = "wishlist")
data class WishlistEntity(
    @PrimaryKey val productId: String,
    val name: String,
    val price: String,
    val imageUrl: String,
    val slug: String,
    val addedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "cart_cache")
data class CartCacheEntity(
    @PrimaryKey val itemId: String,
    val productId: String,
    val name: String,
    val quantity: Int,
    val unitPrice: String,
    val imageUrl: String
)

// ── DAOs ─────────────────────────────────────────────────────

@Dao
interface WishlistDao {
    @Query("SELECT * FROM wishlist ORDER BY addedAt DESC")
    fun getAll(): Flow<List<WishlistEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM wishlist WHERE productId = :id)")
    fun isWishlisted(id: String): Flow<Boolean>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: WishlistEntity)

    @Delete
    suspend fun delete(item: WishlistEntity)

    @Query("DELETE FROM wishlist WHERE productId = :id")
    suspend fun deleteById(id: String)

    @Query("SELECT COUNT(*) FROM wishlist")
    fun count(): Flow<Int>
}

@Dao
interface CartCacheDao {
    @Query("SELECT * FROM cart_cache")
    fun getAll(): Flow<List<CartCacheEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<CartCacheEntity>)

    @Query("DELETE FROM cart_cache")
    suspend fun clearAll()

    @Query("SELECT COUNT(*) FROM cart_cache")
    fun count(): Flow<Int>
}

// ── Database ─────────────────────────────────────────────────

@Database(
    entities = [WishlistEntity::class, CartCacheEntity::class],
    version  = 1,
    exportSchema = false
)
abstract class NovaShopDatabase : RoomDatabase() {
    abstract fun wishlistDao(): WishlistDao
    abstract fun cartCacheDao(): CartCacheDao
}
