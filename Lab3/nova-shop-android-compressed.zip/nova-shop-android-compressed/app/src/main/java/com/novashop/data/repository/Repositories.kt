package com.novashop.data.repository

import com.novashop.data.api.*
import com.novashop.data.db.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import javax.inject.Inject
import javax.inject.Singleton

// ── Result wrapper ────────────────────────────────────────────

sealed class Result<out T> {
    data class Success<T>(val data: T) : Result<T>()
    data class Error(val message: String) : Result<Nothing>()
    object Loading : Result<Nothing>()
}

// ── Auth Repository ───────────────────────────────────────────

@Singleton
class AuthRepository @Inject constructor(
    private val api: NovaShopApi,
    private val tokenManager: TokenManager
) {
    suspend fun login(email: String, password: String): Result<User> {
        return try {
            val response = api.login(LoginRequest(email, password))
            if (response.isSuccessful) {
                val body = response.body()!!
                tokenManager.saveTokens(body.accessToken, body.refreshToken)
                tokenManager.saveUser(body.user)
                Result.Success(body.user)
            } else Result.Error(parseError(response.errorBody()?.string()))
        } catch (e: Exception) { Result.Error(e.message ?: "Network error") }
    }

    suspend fun register(email: String, password: String, name: String): Result<User> {
        return try {
            val response = api.register(RegisterRequest(email, password, name))
            if (response.isSuccessful) {
                val body = response.body()!!
                tokenManager.saveTokens(body.accessToken, body.refreshToken)
                tokenManager.saveUser(body.user)
                Result.Success(body.user)
            } else Result.Error(parseError(response.errorBody()?.string()))
        } catch (e: Exception) { Result.Error(e.message ?: "Network error") }
    }

    suspend fun logout() {
        try {
            val refresh = tokenManager.getRefreshToken()
            if (refresh != null) api.logout(mapOf("refreshToken" to refresh))
        } catch (_: Exception) {}
        tokenManager.clear()
    }

    suspend fun getMe(): Result<User> {
        return try {
            val response = api.getMe()
            if (response.isSuccessful) Result.Success(response.body()!!)
            else Result.Error("Unauthorized")
        } catch (e: Exception) { Result.Error(e.message ?: "Network error") }
    }

    fun isLoggedIn(): Flow<Boolean> = tokenManager.isLoggedIn
    suspend fun getCachedUser(): User? = tokenManager.getUser()
}

// ── Product Repository ────────────────────────────────────────

@Singleton
class ProductRepository @Inject constructor(
    private val api: NovaShopApi
) {
    suspend fun getProducts(
        page: Int = 1, limit: Int = 12,
        search: String? = null, category: String? = null,
        tag: String? = null, sort: String = "created_at",
        order: String = "desc", featured: Boolean? = null
    ): Result<ProductsResponse> {
        return try {
            val r = api.getProducts(page, limit, search, category, tag, sort, order, featured)
            if (r.isSuccessful) Result.Success(r.body()!!)
            else Result.Error("Failed to load products")
        } catch (e: Exception) { Result.Error(e.message ?: "Network error") }
    }

    suspend fun getProduct(slug: String): Result<Product> {
        return try {
            val r = api.getProduct(slug)
            if (r.isSuccessful) Result.Success(r.body()!!)
            else Result.Error("Product not found")
        } catch (e: Exception) { Result.Error(e.message ?: "Network error") }
    }

    suspend fun getCategories(): Result<List<Category>> {
        return try {
            val r = api.getCategories()
            if (r.isSuccessful) Result.Success(r.body()!!)
            else Result.Error("Failed to load categories")
        } catch (e: Exception) { Result.Error(e.message ?: "Network error") }
    }
}

// ── Cart Repository ───────────────────────────────────────────

@Singleton
class CartRepository @Inject constructor(
    private val api: NovaShopApi,
    private val cartCacheDao: CartCacheDao
) {
    val cartCount: Flow<Int> = cartCacheDao.count()

    private suspend fun cacheItems(items: List<CartItem>) {
        cartCacheDao.clearAll()
        cartCacheDao.insertAll(items.map {
            CartCacheEntity(
                it.id,
                it.productId,
                it.name,
                it.quantity,
                it.unitPrice,
                it.imageUrls.firstOrNull() ?: ""
            )
        })
    }

    suspend fun getCart(): Result<List<CartItem>> {
        return try {
            val r = api.getCart()
            if (r.isSuccessful) {
                val items = r.body()!!
                cacheItems(items)
                Result.Success(items)
            } else Result.Error("Failed to load cart")
        } catch (e: Exception) { Result.Error(e.message ?: "Network error") }
    }

    suspend fun addToCart(productId: String, quantity: Int = 1): Result<List<CartItem>> {
        return try {
            val r = api.addToCart(AddToCartRequest(productId, quantity))
            if (r.isSuccessful) {
                val items = r.body()!!
                cacheItems(items)
                Result.Success(items)
            } else Result.Error(parseError(r.errorBody()?.string()))
        } catch (e: Exception) { Result.Error(e.message ?: "Network error") }
    }

    suspend fun updateItem(id: String, quantity: Int): Result<List<CartItem>> {
        return try {
            val r = api.updateCartItem(id, UpdateCartRequest(quantity))
            if (r.isSuccessful) {
                val items = r.body()!!
                cacheItems(items)
                Result.Success(items)
            }
            else Result.Error("Update failed")
        } catch (e: Exception) { Result.Error(e.message ?: "Network error") }
    }

    suspend fun removeItem(id: String): Result<List<CartItem>> {
        return try {
            val r = api.removeCartItem(id)
            if (r.isSuccessful) {
                val items = r.body()!!
                cacheItems(items)
                Result.Success(items)
            }
            else Result.Error("Remove failed")
        } catch (e: Exception) { Result.Error(e.message ?: "Network error") }
    }

    suspend fun clearCart(): Result<Unit> {
        return try {
            api.clearCart()
            cartCacheDao.clearAll()
            Result.Success(Unit)
        } catch (e: Exception) { Result.Error(e.message ?: "Network error") }
    }
}

// ── Wishlist Repository ───────────────────────────────────────

@Singleton
class WishlistRepository @Inject constructor(
    private val wishlistDao: WishlistDao
) {
    fun getAll(): Flow<List<WishlistEntity>> = wishlistDao.getAll()
    fun isWishlisted(id: String): Flow<Boolean> = wishlistDao.isWishlisted(id)
    fun count(): Flow<Int> = wishlistDao.count()

    suspend fun toggle(product: com.novashop.data.api.Product) {
        val entity = WishlistEntity(
            productId = product.id,
            name      = product.name,
            price     = product.price,
            imageUrl  = product.imageUrls.firstOrNull() ?: "",
            slug      = product.slug
        )
        if (wishlistDao.isWishlisted(product.id).first()) {
            wishlistDao.deleteById(product.id)
        } else {
            wishlistDao.insert(entity)
        }
    }

    suspend fun remove(productId: String) = wishlistDao.deleteById(productId)
}

// ── Order Repository ──────────────────────────────────────────

@Singleton
class OrderRepository @Inject constructor(
    private val api: NovaShopApi
) {
    suspend fun checkout(request: CheckoutRequest): Result<Order> {
        return try {
            val r = api.checkout(request)
            val body = r.body()
            if (r.isSuccessful && body != null) Result.Success(body)
            else if (r.isSuccessful) Result.Error("Order created, but response was empty")
            else Result.Error(parseError(r.errorBody()?.string()))
        } catch (e: Exception) { Result.Error(e.message ?: "Network error") }
    }

    suspend fun getOrders(): Result<List<Order>> {
        return try {
            val r = api.getOrders()
            val body = r.body()
            if (r.isSuccessful && body != null) Result.Success(body)
            else Result.Error("Failed to load orders")
        } catch (e: Exception) { Result.Error(e.message ?: "Network error") }
    }

    suspend fun getOrder(id: String): Result<Order> {
        return try {
            val r = api.getOrder(id)
            val body = r.body()
            if (r.isSuccessful && body != null) Result.Success(body)
            else Result.Error("Order not found")
        } catch (e: Exception) { Result.Error(e.message ?: "Network error") }
    }
}

// ── Recommendations Repository ────────────────────────────────

@Singleton
class RecommendationRepository @Inject constructor(
    private val api: NovaShopApi
) {
    suspend fun getRecommendations(limit: Int = 8): Result<List<Recommendation>> {
        return try {
            val r = api.getRecommendations(limit)
            if (r.isSuccessful) Result.Success(r.body()!!)
            else Result.Error("Failed to load recommendations")
        } catch (e: Exception) { Result.Error(e.message ?: "Network error") }
    }
}

// ── Helpers ───────────────────────────────────────────────────

private fun parseError(body: String?): String {
    if (body == null) return "Unknown error"
    return try {
        val json = com.google.gson.JsonParser.parseString(body).asJsonObject
        json.get("error")?.asString ?: "Unknown error"
    } catch (_: Exception) { "Unknown error" }
}
