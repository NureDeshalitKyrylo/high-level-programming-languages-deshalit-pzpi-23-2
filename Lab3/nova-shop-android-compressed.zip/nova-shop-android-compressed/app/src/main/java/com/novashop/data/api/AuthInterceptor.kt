package com.novashop.data.api

import kotlinx.coroutines.runBlocking
import okhttp3.OkHttpClient
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Response
import okhttp3.RequestBody.Companion.toRequestBody
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AuthInterceptor @Inject constructor(
    private val tokenManager: TokenManager
) : Interceptor {

    private val refreshClient = OkHttpClient()

    override fun intercept(chain: Interceptor.Chain): Response {
        val token = runBlocking { tokenManager.getAccessToken() }
        val request = chain.request().newBuilder().apply {
            if (token != null) addHeader("Authorization", "Bearer $token")
        }.build()

        val response = chain.proceed(request)

        // Auto-refresh on 401
        if (response.code == 401) {
            response.close()
            val refreshToken = runBlocking { tokenManager.getRefreshToken() } ?: return response

            val refreshed = runBlocking {
                try {
                    val refreshRequest = okhttp3.Request.Builder()
                        .url(request.url.toString().substringBefore("/api/") + "/api/auth/refresh")
                        .post(
                            """{"refreshToken":"$refreshToken"}"""
                                .toRequestBody("application/json".toMediaType())
                        )
                        .build()
                    refreshClient.newCall(refreshRequest).execute().use { refreshResponse ->
                        if (refreshResponse.isSuccessful) {
                            val body = refreshResponse.body?.string() ?: return@runBlocking null
                            val gson = com.google.gson.Gson()
                            gson.fromJson(body, RefreshResponse::class.java)
                        } else null
                    }
                } catch (e: Exception) { null }
            }

            if (refreshed != null) {
                runBlocking { tokenManager.saveTokens(refreshed.accessToken, refreshed.refreshToken) }
                val newRequest = request.newBuilder()
                    .header("Authorization", "Bearer ${refreshed.accessToken}")
                    .build()
                return refreshClient.newCall(newRequest).execute()
            } else {
                runBlocking { tokenManager.clear() }
            }
        }
        return response
    }
}
