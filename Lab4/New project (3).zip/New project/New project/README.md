# Hotel Booking App

Full-stack hotel booking system built with ASP.NET Core Web API, EF Core, SQLite, and React.

## Features

- Hotels, rooms, customers, bookings, and services data model
- Correct entity relationships and database constraints
- Async database access with `await` + EF Core async APIs
- Safe booking creation with date overlap validation
- Available room lookup with parameterized SQLite query
- React UI for:
  - viewing hotels
  - searching available rooms
  - creating bookings
  - listing bookings
  - deleting bookings

## Backend

Path: [src/HotelBooking.Api](/C:/Users/kiril/OneDrive/Документы/New%20project/src/HotelBooking.Api)

Run:

```powershell
cd "C:\Users\kiril\OneDrive\Документы\New project\src\HotelBooking.Api"
dotnet run
```

API base URL:

- `http://localhost:5033/api`

Database:

- SQLite file is created automatically via EF Core migrations
- Development connection string points to `hotel-booking.dev.db`

## Frontend

Path: [src/HotelBooking.Client](/C:/Users/kiril/OneDrive/Документы/New%20project/src/HotelBooking.Client)

Run:

```powershell
cd "C:\Users\kiril\OneDrive\Документы\New project\src\HotelBooking.Client"
npm.cmd install
npm.cmd run dev
```

Frontend URL:

- `http://localhost:5173`

## Security

- ORM access is implemented with EF Core
- Available room search uses parameterized SQLite command parameters
- No SQL is built by string concatenation from user input

## Verification

- `dotnet build` for backend: passed
- `dotnet ef database update`: passed
- `npm.cmd run build` for frontend: passed
- Live API checks:
  - `GET /api/hotels`: passed
  - `GET /api/bookings/available-rooms`: passed
  - `POST /api/bookings`: passed
  - `DELETE /api/bookings/{id}`: passed
