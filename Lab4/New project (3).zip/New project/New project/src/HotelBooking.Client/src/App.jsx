import { useEffect, useState } from "react";

const API_BASE = "http://localhost:5033/api";

const initialForm = {
  hotelId: "",
  roomId: "",
  customerId: "",
  checkIn: "",
  checkOut: "",
  guestsCount: 1,
  serviceIds: []
};

export default function App() {
  const [hotels, setHotels] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [services, setServices] = useState([]);
  const [rooms, setRooms] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [form, setForm] = useState(initialForm);
  const [message, setMessage] = useState("");
  const [loadingRooms, setLoadingRooms] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    void Promise.all([
      fetchJson("/hotels"),
      fetchJson("/customers"),
      fetchJson("/bookings")
    ]).then(([hotelsData, customersData, bookingsData]) => {
      setHotels(hotelsData);
      setCustomers(customersData);
      setBookings(bookingsData);
      if (hotelsData.length > 0) {
        setForm((current) => ({ ...current, hotelId: String(hotelsData[0].id) }));
      }
    });
  }, []);

  useEffect(() => {
    if (!form.hotelId) {
      setServices([]);
      return;
    }

    void fetchJson(`/services?hotelId=${form.hotelId}`).then((data) => {
      setServices(data.filter((item) => item.isActive));
      setForm((current) => ({
        ...current,
        serviceIds: current.serviceIds.filter((serviceId) =>
          data.some((item) => item.id === serviceId && item.isActive)
        )
      }));
    });
  }, [form.hotelId]);

  async function handleSearchRooms() {
    if (!form.hotelId || !form.checkIn || !form.checkOut) {
      setMessage("Select hotel and dates first.");
      return;
    }

    setLoadingRooms(true);
    setMessage("");
    try {
      const query = new URLSearchParams({
        hotelId: form.hotelId,
        checkIn: form.checkIn,
        checkOut: form.checkOut,
        guestsCount: String(form.guestsCount)
      });
      const data = await fetchJson(`/bookings/available-rooms?${query.toString()}`);
      setRooms(data);
      setForm((current) => ({
        ...current,
        roomId: data[0] ? String(data[0].id) : ""
      }));
      if (data.length === 0) {
        setMessage("No available rooms for the selected dates.");
      }
    } catch (error) {
      setMessage(error.message);
    } finally {
      setLoadingRooms(false);
    }
  }

  async function handleCreateBooking(event) {
    event.preventDefault();
    setSubmitting(true);
    setMessage("");

    try {
      const createdBooking = await fetchJson("/bookings", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          roomId: Number(form.roomId),
          customerId: Number(form.customerId),
          checkIn: form.checkIn,
          checkOut: form.checkOut,
          guestsCount: Number(form.guestsCount),
          serviceIds: form.serviceIds
        })
      });

      setBookings((current) => [...current, createdBooking].sort(compareBookings));
      setMessage("Booking created successfully.");
      setForm((current) => ({
        ...current,
        roomId: "",
        serviceIds: []
      }));
      await handleSearchRooms();
    } catch (error) {
      setMessage(error.message);
    } finally {
      setSubmitting(false);
    }
  }

  async function handleDeleteBooking(bookingId) {
    try {
      await fetchJson(`/bookings/${bookingId}`, { method: "DELETE" });
      setBookings((current) => current.filter((booking) => booking.id !== bookingId));
      setMessage("Booking deleted.");
      if (form.hotelId && form.checkIn && form.checkOut) {
        await handleSearchRooms();
      }
    } catch (error) {
      setMessage(error.message);
    }
  }

  function toggleService(serviceId) {
    setForm((current) => ({
      ...current,
      serviceIds: current.serviceIds.includes(serviceId)
        ? current.serviceIds.filter((id) => id !== serviceId)
        : [...current.serviceIds, serviceId]
    }));
  }

  return (
    <div className="page-shell">
      <div className="hero">
        <p className="eyebrow">ASP.NET + React</p>
        <h1>Hotel booking control center</h1>
        <p className="hero-copy">
          Manage room availability, create bookings asynchronously, and keep data safe with EF Core and parameterized queries.
        </p>
      </div>

      <div className="layout">
        <section className="panel">
          <h2>Create booking</h2>
          <form onSubmit={handleCreateBooking} className="form-grid">
            <label>
              Hotel
              <select
                value={form.hotelId}
                onChange={(event) =>
                  setForm({
                    ...form,
                    hotelId: event.target.value,
                    roomId: "",
                    serviceIds: []
                  })
                }
              >
                {hotels.map((hotel) => (
                  <option key={hotel.id} value={hotel.id}>
                    {hotel.name} ({hotel.city})
                  </option>
                ))}
              </select>
            </label>

            <label>
              Customer
              <select
                value={form.customerId}
                onChange={(event) => setForm({ ...form, customerId: event.target.value })}
              >
                <option value="">Choose customer</option>
                {customers.map((customer) => (
                  <option key={customer.id} value={customer.id}>
                    {customer.firstName} {customer.lastName}
                  </option>
                ))}
              </select>
            </label>

            <label>
              Check-in
              <input
                type="date"
                value={form.checkIn}
                onChange={(event) => setForm({ ...form, checkIn: event.target.value })}
              />
            </label>

            <label>
              Check-out
              <input
                type="date"
                value={form.checkOut}
                onChange={(event) => setForm({ ...form, checkOut: event.target.value })}
              />
            </label>

            <label>
              Guests
              <input
                type="number"
                min="1"
                max="12"
                value={form.guestsCount}
                onChange={(event) => setForm({ ...form, guestsCount: event.target.value })}
              />
            </label>

            <div className="search-box">
              <button type="button" onClick={handleSearchRooms} disabled={loadingRooms}>
                {loadingRooms ? "Searching..." : "Find available rooms"}
              </button>
            </div>

            <label className="wide">
              Available room
              <select
                value={form.roomId}
                onChange={(event) => setForm({ ...form, roomId: event.target.value })}
              >
                <option value="">Choose room</option>
                {rooms.map((room) => (
                  <option key={room.id} value={room.id}>
                    {room.number} · {room.type} · {room.pricePerNight} UAH
                  </option>
                ))}
              </select>
            </label>

            <div className="wide">
              <p className="field-caption">Extra services</p>
              <div className="service-list">
                {services.map((service) => (
                  <label key={service.id} className="chip">
                    <input
                      type="checkbox"
                      checked={form.serviceIds.includes(service.id)}
                      onChange={() => toggleService(service.id)}
                    />
                    <span>
                      {service.name} · {service.price} UAH
                    </span>
                  </label>
                ))}
              </div>
            </div>

            <button
              type="submit"
              className="primary wide"
              disabled={submitting || !form.roomId || !form.customerId}
            >
              {submitting ? "Saving..." : "Create booking"}
            </button>
          </form>

          {message ? <p className="message">{message}</p> : null}
        </section>

        <section className="panel">
          <h2>Current bookings</h2>
          <div className="booking-list">
            {bookings.map((booking) => (
              <article key={booking.id} className="booking-card">
                <div>
                  <strong>Room {booking.roomNumber}</strong>
                  <p>{booking.customerName}</p>
                  <p>
                    {booking.checkIn} to {booking.checkOut}
                  </p>
                  <p>{booking.totalRoomPrice} UAH</p>
                  <p>{booking.services.length > 0 ? booking.services.join(", ") : "No extra services"}</p>
                </div>
                <button type="button" onClick={() => handleDeleteBooking(booking.id)}>
                  Delete
                </button>
              </article>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}

async function fetchJson(path, options) {
  const response = await fetch(`${API_BASE}${path}`, options);
  if (!response.ok) {
    const text = await response.text();
    throw new Error(text || "Request failed.");
  }

  if (response.status === 204) {
    return null;
  }

  return response.json();
}

function compareBookings(left, right) {
  return left.checkIn.localeCompare(right.checkIn);
}
