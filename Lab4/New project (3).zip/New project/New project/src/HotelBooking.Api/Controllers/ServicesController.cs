using HotelBooking.Api.Contracts;
using HotelBooking.Api.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HotelBooking.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ServicesController(HotelBookingDbContext dbContext) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<IReadOnlyCollection<ServiceDto>>> GetServices([FromQuery] int hotelId, CancellationToken cancellationToken)
    {
        var services = await dbContext.Services
            .AsNoTracking()
            .Where(s => hotelId == 0 || s.HotelId == hotelId)
            .OrderBy(s => s.Name)
            .Select(s => new ServiceDto(s.Id, s.HotelId, s.Name, s.Price, s.IsActive))
            .ToListAsync(cancellationToken);

        return Ok(services);
    }

    [HttpGet("{id:int}")]
    public async Task<ActionResult<ServiceDto>> GetService(int id, CancellationToken cancellationToken)
    {
        var service = await dbContext.Services
            .AsNoTracking()
            .Where(s => s.Id == id)
            .Select(s => new ServiceDto(s.Id, s.HotelId, s.Name, s.Price, s.IsActive))
            .FirstOrDefaultAsync(cancellationToken);

        return service is null ? NotFound() : Ok(service);
    }

    [HttpPost]
    public async Task<ActionResult<ServiceDto>> CreateService([FromBody] UpsertServiceRequest request, CancellationToken cancellationToken)
    {
        var hotelExists = await dbContext.Hotels.AnyAsync(h => h.Id == request.HotelId, cancellationToken);
        if (!hotelExists)
        {
            return BadRequest("Hotel does not exist.");
        }

        var service = new Models.Service
        {
            HotelId = request.HotelId,
            Name = request.Name,
            Price = request.Price,
            IsActive = request.IsActive
        };

        dbContext.Services.Add(service);
        await dbContext.SaveChangesAsync(cancellationToken);

        return CreatedAtAction(nameof(GetService), new { id = service.Id }, new ServiceDto(service.Id, service.HotelId, service.Name, service.Price, service.IsActive));
    }

    [HttpPut("{id:int}")]
    public async Task<ActionResult<ServiceDto>> UpdateService(int id, [FromBody] UpsertServiceRequest request, CancellationToken cancellationToken)
    {
        var service = await dbContext.Services.FirstOrDefaultAsync(s => s.Id == id, cancellationToken);
        if (service is null)
        {
            return NotFound();
        }

        var hotelExists = await dbContext.Hotels.AnyAsync(h => h.Id == request.HotelId, cancellationToken);
        if (!hotelExists)
        {
            return BadRequest("Hotel does not exist.");
        }

        service.HotelId = request.HotelId;
        service.Name = request.Name;
        service.Price = request.Price;
        service.IsActive = request.IsActive;
        await dbContext.SaveChangesAsync(cancellationToken);

        return Ok(new ServiceDto(service.Id, service.HotelId, service.Name, service.Price, service.IsActive));
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> DeleteService(int id, CancellationToken cancellationToken)
    {
        var service = await dbContext.Services.FirstOrDefaultAsync(s => s.Id == id, cancellationToken);
        if (service is null)
        {
            return NotFound();
        }

        dbContext.Services.Remove(service);
        await dbContext.SaveChangesAsync(cancellationToken);
        return NoContent();
    }
}
