using HotelBooking.Api.Contracts;
using HotelBooking.Api.Services;
using Microsoft.AspNetCore.Mvc;

namespace HotelBooking.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class BookingsController(IBookingService bookingService) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<IReadOnlyCollection<BookingDto>>> GetBookings(CancellationToken cancellationToken)
    {
        var bookings = await bookingService.GetBookingsAsync(cancellationToken);
        return Ok(bookings);
    }

    [HttpGet("{id:int}")]
    public async Task<ActionResult<BookingDto>> GetBooking(int id, CancellationToken cancellationToken)
    {
        var booking = await bookingService.GetBookingByIdAsync(id, cancellationToken);
        return booking is null ? NotFound() : Ok(booking);
    }

    [HttpGet("available-rooms")]
    public async Task<ActionResult<IReadOnlyCollection<RoomDto>>> GetAvailableRooms(
        [FromQuery] AvailableRoomsQuery query,
        CancellationToken cancellationToken)
    {
        var rooms = await bookingService.GetAvailableRoomsAsync(query, cancellationToken);
        return Ok(rooms);
    }

    [HttpPost]
    public async Task<ActionResult<BookingDto>> CreateBooking(
        [FromBody] CreateBookingRequest request,
        CancellationToken cancellationToken)
    {
        var booking = await bookingService.CreateBookingAsync(request, cancellationToken);
        if (booking is null)
        {
            return BadRequest("Unable to create booking. Check dates, guest count, room availability, and selected services.");
        }

        return CreatedAtAction(nameof(GetBooking), new { id = booking.Id }, booking);
    }

    [HttpPut("{id:int}")]
    public async Task<ActionResult<BookingDto>> UpdateBooking(
        int id,
        [FromBody] UpdateBookingRequest request,
        CancellationToken cancellationToken)
    {
        var booking = await bookingService.UpdateBookingAsync(id, request, cancellationToken);
        if (booking is null)
        {
            return BadRequest("Unable to update booking. Check booking id, dates, guest count, room availability, and selected services.");
        }

        return Ok(booking);
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> DeleteBooking(int id, CancellationToken cancellationToken)
    {
        var deleted = await bookingService.DeleteBookingAsync(id, cancellationToken);
        return deleted ? NoContent() : NotFound();
    }
}
