using HotelBooking.Api.Contracts;
using HotelBooking.Api.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HotelBooking.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class HotelsController(HotelBookingDbContext dbContext) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<IReadOnlyCollection<HotelDto>>> GetHotels(CancellationToken cancellationToken)
    {
        var hotels = await dbContext.Hotels
            .AsNoTracking()
            .OrderBy(h => h.City)
            .ThenBy(h => h.Name)
            .Select(h => new HotelDto(h.Id, h.Name, h.City, h.Address))
            .ToListAsync(cancellationToken);

        return Ok(hotels);
    }

    [HttpGet("{id:int}")]
    public async Task<ActionResult<HotelDto>> GetHotel(int id, CancellationToken cancellationToken)
    {
        var hotel = await dbContext.Hotels
            .AsNoTracking()
            .Where(h => h.Id == id)
            .Select(h => new HotelDto(h.Id, h.Name, h.City, h.Address))
            .FirstOrDefaultAsync(cancellationToken);

        return hotel is null ? NotFound() : Ok(hotel);
    }

    [HttpPost]
    public async Task<ActionResult<HotelDto>> CreateHotel([FromBody] UpsertHotelRequest request, CancellationToken cancellationToken)
    {
        var hotel = new Models.Hotel
        {
            Name = request.Name,
            City = request.City,
            Address = request.Address
        };

        dbContext.Hotels.Add(hotel);
        await dbContext.SaveChangesAsync(cancellationToken);

        return CreatedAtAction(nameof(GetHotel), new { id = hotel.Id }, new HotelDto(hotel.Id, hotel.Name, hotel.City, hotel.Address));
    }

    [HttpPut("{id:int}")]
    public async Task<ActionResult<HotelDto>> UpdateHotel(int id, [FromBody] UpsertHotelRequest request, CancellationToken cancellationToken)
    {
        var hotel = await dbContext.Hotels.FirstOrDefaultAsync(h => h.Id == id, cancellationToken);
        if (hotel is null)
        {
            return NotFound();
        }

        hotel.Name = request.Name;
        hotel.City = request.City;
        hotel.Address = request.Address;
        await dbContext.SaveChangesAsync(cancellationToken);

        return Ok(new HotelDto(hotel.Id, hotel.Name, hotel.City, hotel.Address));
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> DeleteHotel(int id, CancellationToken cancellationToken)
    {
        var hotel = await dbContext.Hotels.FirstOrDefaultAsync(h => h.Id == id, cancellationToken);
        if (hotel is null)
        {
            return NotFound();
        }

        dbContext.Hotels.Remove(hotel);
        await dbContext.SaveChangesAsync(cancellationToken);
        return NoContent();
    }
}
