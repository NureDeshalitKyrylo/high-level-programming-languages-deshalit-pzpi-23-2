using HotelBooking.Api.Contracts;
using HotelBooking.Api.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HotelBooking.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class RoomsController(HotelBookingDbContext dbContext) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<IReadOnlyCollection<RoomDto>>> GetRooms([FromQuery] int hotelId, CancellationToken cancellationToken)
    {
        var rooms = await dbContext.Rooms
            .AsNoTracking()
            .Include(r => r.Hotel)
            .Where(r => hotelId == 0 || r.HotelId == hotelId)
            .OrderBy(r => r.Number)
            .Select(r => new RoomDto(r.Id, r.HotelId, r.Hotel!.Name, r.Number, r.Type, r.Capacity, r.PricePerNight))
            .ToListAsync(cancellationToken);

        return Ok(rooms);
    }

    [HttpGet("{id:int}")]
    public async Task<ActionResult<RoomDto>> GetRoom(int id, CancellationToken cancellationToken)
    {
        var room = await dbContext.Rooms
            .AsNoTracking()
            .Include(r => r.Hotel)
            .Where(r => r.Id == id)
            .Select(r => new RoomDto(r.Id, r.HotelId, r.Hotel!.Name, r.Number, r.Type, r.Capacity, r.PricePerNight))
            .FirstOrDefaultAsync(cancellationToken);

        return room is null ? NotFound() : Ok(room);
    }

    [HttpPost]
    public async Task<ActionResult<RoomDto>> CreateRoom([FromBody] UpsertRoomRequest request, CancellationToken cancellationToken)
    {
        var hotel = await dbContext.Hotels.FirstOrDefaultAsync(h => h.Id == request.HotelId, cancellationToken);
        if (hotel is null)
        {
            return BadRequest("Hotel does not exist.");
        }

        var room = new Models.Room
        {
            HotelId = request.HotelId,
            Number = request.Number,
            Type = request.Type,
            Capacity = request.Capacity,
            PricePerNight = request.PricePerNight,
            IsActive = request.IsActive
        };

        dbContext.Rooms.Add(room);
        await dbContext.SaveChangesAsync(cancellationToken);

        return CreatedAtAction(nameof(GetRoom), new { id = room.Id }, new RoomDto(room.Id, room.HotelId, hotel.Name, room.Number, room.Type, room.Capacity, room.PricePerNight));
    }

    [HttpPut("{id:int}")]
    public async Task<ActionResult<RoomDto>> UpdateRoom(int id, [FromBody] UpsertRoomRequest request, CancellationToken cancellationToken)
    {
        var room = await dbContext.Rooms.Include(r => r.Hotel).FirstOrDefaultAsync(r => r.Id == id, cancellationToken);
        if (room is null)
        {
            return NotFound();
        }

        var hotel = await dbContext.Hotels.FirstOrDefaultAsync(h => h.Id == request.HotelId, cancellationToken);
        if (hotel is null)
        {
            return BadRequest("Hotel does not exist.");
        }

        room.HotelId = request.HotelId;
        room.Number = request.Number;
        room.Type = request.Type;
        room.Capacity = request.Capacity;
        room.PricePerNight = request.PricePerNight;
        room.IsActive = request.IsActive;
        await dbContext.SaveChangesAsync(cancellationToken);

        return Ok(new RoomDto(room.Id, room.HotelId, hotel.Name, room.Number, room.Type, room.Capacity, room.PricePerNight));
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> DeleteRoom(int id, CancellationToken cancellationToken)
    {
        var room = await dbContext.Rooms.FirstOrDefaultAsync(r => r.Id == id, cancellationToken);
        if (room is null)
        {
            return NotFound();
        }

        dbContext.Rooms.Remove(room);
        await dbContext.SaveChangesAsync(cancellationToken);
        return NoContent();
    }
}
