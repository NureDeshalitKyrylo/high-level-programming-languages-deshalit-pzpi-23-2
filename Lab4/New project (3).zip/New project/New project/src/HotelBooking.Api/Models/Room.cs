using System.ComponentModel.DataAnnotations;

namespace HotelBooking.Api.Models;

public class Room
{
    public int Id { get; set; }

    public int HotelId { get; set; }

    [Required]
    [MaxLength(20)]
    public string Number { get; set; } = string.Empty;

    [Required]
    [MaxLength(30)]
    public string Type { get; set; } = string.Empty;

    [Range(1, 12)]
    public int Capacity { get; set; }

    [Range(0, 100000)]
    public decimal PricePerNight { get; set; }

    public bool IsActive { get; set; } = true;

    public Hotel? Hotel { get; set; }

    public ICollection<Booking> Bookings { get; set; } = [];
}
