using System.ComponentModel.DataAnnotations;

namespace HotelBooking.Api.Models;

public class Service
{
    public int Id { get; set; }

    public int HotelId { get; set; }

    [Required]
    [MaxLength(100)]
    public string Name { get; set; } = string.Empty;

    [Range(0, 100000)]
    public decimal Price { get; set; }

    public bool IsActive { get; set; } = true;

    public Hotel? Hotel { get; set; }

    public ICollection<Booking> Bookings { get; set; } = [];
}
