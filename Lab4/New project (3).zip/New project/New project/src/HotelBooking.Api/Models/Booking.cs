using System.ComponentModel.DataAnnotations;

namespace HotelBooking.Api.Models;

public class Booking
{
    public int Id { get; set; }

    public int RoomId { get; set; }

    public int CustomerId { get; set; }

    public DateOnly CheckIn { get; set; }

    public DateOnly CheckOut { get; set; }

    [Range(1, 12)]
    public int GuestsCount { get; set; }

    [MaxLength(25)]
    public string Status { get; set; } = "Confirmed";

    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;

    public Room? Room { get; set; }

    public Customer? Customer { get; set; }

    public ICollection<Service> Services { get; set; } = [];
}
