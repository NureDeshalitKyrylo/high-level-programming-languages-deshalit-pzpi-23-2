using System.ComponentModel.DataAnnotations;

namespace HotelBooking.Api.Models;

public class Hotel
{
    public int Id { get; set; }

    [Required]
    [MaxLength(150)]
    public string Name { get; set; } = string.Empty;

    [Required]
    [MaxLength(120)]
    public string City { get; set; } = string.Empty;

    [MaxLength(250)]
    public string? Address { get; set; }

    public ICollection<Room> Rooms { get; set; } = [];

    public ICollection<Service> Services { get; set; } = [];
}
