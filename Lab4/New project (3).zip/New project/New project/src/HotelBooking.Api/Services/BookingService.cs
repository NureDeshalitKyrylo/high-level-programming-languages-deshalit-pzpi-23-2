using HotelBooking.Api.Contracts;
using HotelBooking.Api.Data;
using HotelBooking.Api.Models;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;

namespace HotelBooking.Api.Services;

public class BookingService(HotelBookingDbContext dbContext) : IBookingService
{
    public async Task<IReadOnlyCollection<BookingDto>> GetBookingsAsync(CancellationToken cancellationToken)
    {
        var bookings = await dbContext.Bookings
            .AsNoTracking()
            .Include(b => b.Room)
            .Include(b => b.Customer)
            .Include(b => b.Services)
            .OrderBy(b => b.CheckIn)
            .ToListAsync(cancellationToken);

        return bookings.Select(MapBooking).ToArray();
    }

    public async Task<BookingDto?> GetBookingByIdAsync(int bookingId, CancellationToken cancellationToken)
    {
        var booking = await dbContext.Bookings
            .AsNoTracking()
            .Include(b => b.Room)
            .Include(b => b.Customer)
            .Include(b => b.Services)
            .FirstOrDefaultAsync(b => b.Id == bookingId, cancellationToken);

        return booking is null ? null : MapBooking(booking);
    }

    public async Task<BookingDto?> CreateBookingAsync(CreateBookingRequest request, CancellationToken cancellationToken)
    {
        if (request.CheckIn >= request.CheckOut)
        {
            return null;
        }

        var room = await dbContext.Rooms
            .Include(r => r.Hotel)
            .FirstOrDefaultAsync(r => r.Id == request.RoomId && r.IsActive, cancellationToken);

        var customer = await dbContext.Customers
            .FirstOrDefaultAsync(c => c.Id == request.CustomerId, cancellationToken);

        if (room is null || customer is null || request.GuestsCount > room.Capacity)
        {
            return null;
        }

        var hasConflict = await dbContext.Bookings
            .AnyAsync(
                b => b.RoomId == request.RoomId &&
                     b.Status != "Cancelled" &&
                     request.CheckIn < b.CheckOut &&
                     request.CheckOut > b.CheckIn,
                cancellationToken);

        if (hasConflict)
        {
            return null;
        }

        var services = await dbContext.Services
            .Where(s => request.ServiceIds.Contains(s.Id) && s.HotelId == room.HotelId && s.IsActive)
            .ToListAsync(cancellationToken);

        var booking = new Booking
        {
            RoomId = room.Id,
            CustomerId = customer.Id,
            CheckIn = request.CheckIn,
            CheckOut = request.CheckOut,
            GuestsCount = request.GuestsCount,
            Services = services
        };

        dbContext.Bookings.Add(booking);
        await dbContext.SaveChangesAsync(cancellationToken);

        var createdBooking = await dbContext.Bookings
            .AsNoTracking()
            .Include(b => b.Room)
            .Include(b => b.Customer)
            .Include(b => b.Services)
            .FirstAsync(b => b.Id == booking.Id, cancellationToken);

        return MapBooking(createdBooking);
    }

    public async Task<BookingDto?> UpdateBookingAsync(int bookingId, UpdateBookingRequest request, CancellationToken cancellationToken)
    {
        if (request.CheckIn >= request.CheckOut)
        {
            return null;
        }

        var booking = await dbContext.Bookings
            .Include(b => b.Services)
            .FirstOrDefaultAsync(b => b.Id == bookingId, cancellationToken);

        if (booking is null)
        {
            return null;
        }

        var room = await dbContext.Rooms
            .Include(r => r.Hotel)
            .FirstOrDefaultAsync(r => r.Id == request.RoomId && r.IsActive, cancellationToken);

        var customer = await dbContext.Customers
            .FirstOrDefaultAsync(c => c.Id == request.CustomerId, cancellationToken);

        if (room is null || customer is null || request.GuestsCount > room.Capacity)
        {
            return null;
        }

        var hasConflict = await dbContext.Bookings
            .AnyAsync(
                b => b.Id != bookingId &&
                     b.RoomId == request.RoomId &&
                     b.Status != "Cancelled" &&
                     request.CheckIn < b.CheckOut &&
                     request.CheckOut > b.CheckIn,
                cancellationToken);

        if (hasConflict)
        {
            return null;
        }

        var services = await dbContext.Services
            .Where(s => request.ServiceIds.Contains(s.Id) && s.HotelId == room.HotelId && s.IsActive)
            .ToListAsync(cancellationToken);

        booking.RoomId = room.Id;
        booking.CustomerId = customer.Id;
        booking.CheckIn = request.CheckIn;
        booking.CheckOut = request.CheckOut;
        booking.GuestsCount = request.GuestsCount;
        booking.Status = request.Status;
        booking.Services.Clear();
        foreach (var service in services)
        {
            booking.Services.Add(service);
        }

        await dbContext.SaveChangesAsync(cancellationToken);

        var updatedBooking = await dbContext.Bookings
            .AsNoTracking()
            .Include(b => b.Room)
            .Include(b => b.Customer)
            .Include(b => b.Services)
            .FirstAsync(b => b.Id == bookingId, cancellationToken);

        return MapBooking(updatedBooking);
    }

    public async Task<bool> DeleteBookingAsync(int bookingId, CancellationToken cancellationToken)
    {
        var booking = await dbContext.Bookings.FirstOrDefaultAsync(b => b.Id == bookingId, cancellationToken);
        if (booking is null)
        {
            return false;
        }

        dbContext.Bookings.Remove(booking);
        await dbContext.SaveChangesAsync(cancellationToken);
        return true;
    }

    public async Task<IReadOnlyCollection<RoomDto>> GetAvailableRoomsAsync(AvailableRoomsQuery query, CancellationToken cancellationToken)
    {
        if (query.CheckIn >= query.CheckOut)
        {
            return [];
        }

        var roomIds = await GetAvailableRoomIdsAsync(query, cancellationToken);

        var rooms = await dbContext.Rooms
            .AsNoTracking()
            .Include(r => r.Hotel)
            .Where(r => roomIds.Contains(r.Id))
            .Select(r => new RoomDto(
                r.Id,
                r.HotelId,
                r.Hotel!.Name,
                r.Number,
                r.Type,
                r.Capacity,
                r.PricePerNight))
            .ToListAsync(cancellationToken);

        return rooms.OrderBy(r => r.PricePerNight).ToArray();
    }

    private async Task<List<int>> GetAvailableRoomIdsAsync(AvailableRoomsQuery query, CancellationToken cancellationToken)
    {
        var connectionString = dbContext.Database.GetConnectionString()
            ?? throw new InvalidOperationException("Database connection string is not configured.");

        await using var connection = new SqliteConnection(connectionString);
        await connection.OpenAsync(cancellationToken);

        await using var command = connection.CreateCommand();
        command.CommandText = """
            SELECT r.Id
            FROM Rooms AS r
            WHERE r.HotelId = $hotelId
              AND r.IsActive = 1
              AND r.Capacity >= $guestsCount
              AND NOT EXISTS (
                SELECT 1
                FROM Bookings AS b
                WHERE b.RoomId = r.Id
                  AND b.Status <> 'Cancelled'
                  AND $checkIn < b.CheckOut
                  AND $checkOut > b.CheckIn
              );
            """;

        command.Parameters.Add(new SqliteParameter("$hotelId", query.HotelId));
        command.Parameters.Add(new SqliteParameter("$guestsCount", query.GuestsCount));
        command.Parameters.Add(new SqliteParameter("$checkIn", query.CheckIn.ToString("yyyy-MM-dd")));
        command.Parameters.Add(new SqliteParameter("$checkOut", query.CheckOut.ToString("yyyy-MM-dd")));

        var roomIds = new List<int>();
        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
        {
            roomIds.Add(reader.GetInt32(0));
        }

        return roomIds;
    }

    private static BookingDto MapBooking(Booking booking)
    {
        var nights = booking.CheckOut.DayNumber - booking.CheckIn.DayNumber;
        var totalRoomPrice = nights * booking.Room!.PricePerNight;

        return new BookingDto(
            booking.Id,
            booking.RoomId,
            booking.Room.Number,
            booking.CustomerId,
            $"{booking.Customer!.FirstName} {booking.Customer.LastName}",
            booking.CheckIn,
            booking.CheckOut,
            booking.GuestsCount,
            booking.Status,
            totalRoomPrice,
            booking.Services.Select(s => s.Name).OrderBy(name => name).ToArray()
        );
    }
}
