using HotelBooking.Api.Contracts;

namespace HotelBooking.Api.Services;

public interface IBookingService
{
    Task<IReadOnlyCollection<BookingDto>> GetBookingsAsync(CancellationToken cancellationToken);
    Task<BookingDto?> GetBookingByIdAsync(int bookingId, CancellationToken cancellationToken);
    Task<BookingDto?> CreateBookingAsync(CreateBookingRequest request, CancellationToken cancellationToken);
    Task<BookingDto?> UpdateBookingAsync(int bookingId, UpdateBookingRequest request, CancellationToken cancellationToken);
    Task<bool> DeleteBookingAsync(int bookingId, CancellationToken cancellationToken);
    Task<IReadOnlyCollection<RoomDto>> GetAvailableRoomsAsync(AvailableRoomsQuery query, CancellationToken cancellationToken);
}
