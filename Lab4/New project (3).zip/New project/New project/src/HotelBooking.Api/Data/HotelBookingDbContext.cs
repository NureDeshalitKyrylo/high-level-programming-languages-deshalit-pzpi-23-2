using HotelBooking.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace HotelBooking.Api.Data;

public class HotelBookingDbContext(DbContextOptions<HotelBookingDbContext> options) : DbContext(options)
{
    public DbSet<Hotel> Hotels => Set<Hotel>();
    public DbSet<Room> Rooms => Set<Room>();
    public DbSet<Customer> Customers => Set<Customer>();
    public DbSet<Booking> Bookings => Set<Booking>();
    public DbSet<Service> Services => Set<Service>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Hotel>()
            .HasIndex(h => new { h.Name, h.City })
            .IsUnique();

        modelBuilder.Entity<Room>()
            .HasIndex(r => new { r.HotelId, r.Number })
            .IsUnique();

        modelBuilder.Entity<Customer>()
            .HasIndex(c => c.Email)
            .IsUnique();

        modelBuilder.Entity<Service>()
            .HasIndex(s => new { s.HotelId, s.Name })
            .IsUnique();

        modelBuilder.Entity<Booking>()
            .ToTable(t => t.HasCheckConstraint("CK_Bookings_Dates", "\"CheckIn\" < \"CheckOut\""));

        modelBuilder.Entity<Booking>()
            .Property(b => b.Status)
            .HasDefaultValue("Confirmed");

        modelBuilder.Entity<Booking>()
            .HasOne(b => b.Room)
            .WithMany(r => r.Bookings)
            .HasForeignKey(b => b.RoomId)
            .OnDelete(DeleteBehavior.Restrict);

        modelBuilder.Entity<Booking>()
            .HasOne(b => b.Customer)
            .WithMany(c => c.Bookings)
            .HasForeignKey(b => b.CustomerId)
            .OnDelete(DeleteBehavior.Restrict);

        modelBuilder.Entity<Service>()
            .HasOne(s => s.Hotel)
            .WithMany(h => h.Services)
            .HasForeignKey(s => s.HotelId)
            .OnDelete(DeleteBehavior.Cascade);

        modelBuilder.Entity<Room>()
            .HasOne(r => r.Hotel)
            .WithMany(h => h.Rooms)
            .HasForeignKey(r => r.HotelId)
            .OnDelete(DeleteBehavior.Cascade);

        modelBuilder.Entity<Booking>()
            .HasMany(b => b.Services)
            .WithMany(s => s.Bookings)
            .UsingEntity<Dictionary<string, object>>(
                "BookingServices",
                right => right.HasOne<Service>().WithMany().HasForeignKey("ServicesId"),
                left => left.HasOne<Booking>().WithMany().HasForeignKey("BookingsId"),
                join =>
                {
                    join.ToTable("BookingServices");
                    join.HasKey("BookingsId", "ServicesId");
                });

        Seed(modelBuilder);
    }

    private static void Seed(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Hotel>().HasData(
            new Hotel { Id = 1, Name = "Skyline Hotel", City = "Kyiv", Address = "Khreshchatyk St. 10" },
            new Hotel { Id = 2, Name = "Sea Breeze Resort", City = "Odesa", Address = "Lanzheron Beach 3" },
            new Hotel { Id = 3, Name = "Carpathian Escape", City = "Lviv", Address = "Svobody Ave. 25" },
            new Hotel { Id = 4, Name = "Riverside Park Hotel", City = "Dnipro", Address = "Central Embankment 8" }
        );

        modelBuilder.Entity<Room>().HasData(
            new Room { Id = 1, HotelId = 1, Number = "101", Type = "Standard", Capacity = 2, PricePerNight = 2500m, IsActive = true },
            new Room { Id = 2, HotelId = 1, Number = "102", Type = "Deluxe", Capacity = 3, PricePerNight = 3900m, IsActive = true },
            new Room { Id = 3, HotelId = 2, Number = "201", Type = "Suite", Capacity = 4, PricePerNight = 5500m, IsActive = true },
            new Room { Id = 4, HotelId = 2, Number = "202", Type = "Standard", Capacity = 2, PricePerNight = 2300m, IsActive = true },
            new Room { Id = 5, HotelId = 1, Number = "103", Type = "Business", Capacity = 2, PricePerNight = 3200m, IsActive = true },
            new Room { Id = 6, HotelId = 2, Number = "203", Type = "Family", Capacity = 5, PricePerNight = 6100m, IsActive = true },
            new Room { Id = 7, HotelId = 3, Number = "301", Type = "Standard", Capacity = 2, PricePerNight = 2100m, IsActive = true },
            new Room { Id = 8, HotelId = 3, Number = "302", Type = "Deluxe", Capacity = 3, PricePerNight = 3600m, IsActive = true },
            new Room { Id = 9, HotelId = 3, Number = "303", Type = "Suite", Capacity = 4, PricePerNight = 4900m, IsActive = true },
            new Room { Id = 10, HotelId = 4, Number = "401", Type = "Standard", Capacity = 2, PricePerNight = 2400m, IsActive = true },
            new Room { Id = 11, HotelId = 4, Number = "402", Type = "Deluxe", Capacity = 3, PricePerNight = 3800m, IsActive = true },
            new Room { Id = 12, HotelId = 4, Number = "403", Type = "Apartment", Capacity = 4, PricePerNight = 5200m, IsActive = true }
        );

        modelBuilder.Entity<Customer>().HasData(
            new Customer { Id = 1, FirstName = "Olena", LastName = "Koval", Email = "olena.koval@example.com", Phone = "+380501112233" },
            new Customer { Id = 2, FirstName = "Andrii", LastName = "Melnyk", Email = "andrii.melnyk@example.com", Phone = "+380671234567" },
            new Customer { Id = 3, FirstName = "Iryna", LastName = "Shevchenko", Email = "iryna.shevchenko@example.com", Phone = "+380931112244" },
            new Customer { Id = 4, FirstName = "Maksym", LastName = "Bondarenko", Email = "maksym.bondarenko@example.com", Phone = "+380661998877" },
            new Customer { Id = 5, FirstName = "Sofiia", LastName = "Tkachenko", Email = "sofiia.tkachenko@example.com", Phone = "+380731234500" },
            new Customer { Id = 6, FirstName = "Dmytro", LastName = "Havryliuk", Email = "dmytro.havryliuk@example.com", Phone = "+380971234111" }
        );

        modelBuilder.Entity<Service>().HasData(
            new Service { Id = 1, HotelId = 1, Name = "Breakfast", Price = 450m, IsActive = true },
            new Service { Id = 2, HotelId = 1, Name = "Airport Transfer", Price = 900m, IsActive = true },
            new Service { Id = 3, HotelId = 2, Name = "Spa Access", Price = 1200m, IsActive = true },
            new Service { Id = 4, HotelId = 2, Name = "Late Checkout", Price = 600m, IsActive = true },
            new Service { Id = 5, HotelId = 1, Name = "Laundry", Price = 300m, IsActive = true },
            new Service { Id = 6, HotelId = 2, Name = "Private Beach Access", Price = 1500m, IsActive = true },
            new Service { Id = 7, HotelId = 3, Name = "Mountain Tour", Price = 1800m, IsActive = true },
            new Service { Id = 8, HotelId = 3, Name = "Breakfast", Price = 400m, IsActive = true },
            new Service { Id = 9, HotelId = 4, Name = "Conference Hall", Price = 2500m, IsActive = true },
            new Service { Id = 10, HotelId = 4, Name = "Parking", Price = 250m, IsActive = true }
        );

        modelBuilder.Entity<Booking>().HasData(
            new Booking
            {
                Id = 1,
                RoomId = 1,
                CustomerId = 1,
                CheckIn = new DateOnly(2026, 6, 10),
                CheckOut = new DateOnly(2026, 6, 14),
                GuestsCount = 2,
                Status = "Confirmed",
                CreatedAtUtc = new DateTime(2026, 5, 20, 12, 0, 0, DateTimeKind.Utc)
            },
            new Booking
            {
                Id = 2,
                RoomId = 3,
                CustomerId = 3,
                CheckIn = new DateOnly(2026, 6, 18),
                CheckOut = new DateOnly(2026, 6, 22),
                GuestsCount = 3,
                Status = "Confirmed",
                CreatedAtUtc = new DateTime(2026, 5, 22, 9, 30, 0, DateTimeKind.Utc)
            },
            new Booking
            {
                Id = 3,
                RoomId = 7,
                CustomerId = 4,
                CheckIn = new DateOnly(2026, 6, 8),
                CheckOut = new DateOnly(2026, 6, 11),
                GuestsCount = 2,
                Status = "Confirmed",
                CreatedAtUtc = new DateTime(2026, 5, 24, 14, 15, 0, DateTimeKind.Utc)
            },
            new Booking
            {
                Id = 4,
                RoomId = 11,
                CustomerId = 5,
                CheckIn = new DateOnly(2026, 6, 15),
                CheckOut = new DateOnly(2026, 6, 17),
                GuestsCount = 2,
                Status = "Confirmed",
                CreatedAtUtc = new DateTime(2026, 5, 25, 16, 45, 0, DateTimeKind.Utc)
            },
            new Booking
            {
                Id = 5,
                RoomId = 5,
                CustomerId = 6,
                CheckIn = new DateOnly(2026, 6, 20),
                CheckOut = new DateOnly(2026, 6, 24),
                GuestsCount = 1,
                Status = "Pending",
                CreatedAtUtc = new DateTime(2026, 5, 27, 11, 10, 0, DateTimeKind.Utc)
            }
        );

        modelBuilder.Entity("BookingServices").HasData(
            new { BookingsId = 1, ServicesId = 1 },
            new { BookingsId = 2, ServicesId = 3 },
            new { BookingsId = 2, ServicesId = 6 },
            new { BookingsId = 3, ServicesId = 7 },
            new { BookingsId = 3, ServicesId = 8 },
            new { BookingsId = 4, ServicesId = 10 },
            new { BookingsId = 5, ServicesId = 2 },
            new { BookingsId = 5, ServicesId = 5 }
        );
    }
}
