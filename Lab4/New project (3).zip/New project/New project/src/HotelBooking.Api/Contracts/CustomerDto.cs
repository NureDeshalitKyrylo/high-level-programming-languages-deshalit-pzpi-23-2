namespace HotelBooking.Api.Contracts;

public record CustomerDto(int Id, string FirstName, string LastName, string Email, string? Phone);
