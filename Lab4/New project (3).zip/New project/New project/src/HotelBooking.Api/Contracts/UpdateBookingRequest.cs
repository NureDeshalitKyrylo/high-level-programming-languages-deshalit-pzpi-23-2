using System.ComponentModel.DataAnnotations;

namespace HotelBooking.Api.Contracts;

public class UpdateBookingRequest
{
    [Range(1, int.MaxValue)]
    public int RoomId { get; set; }

    [Range(1, int.MaxValue)]
    public int CustomerId { get; set; }

    public DateOnly CheckIn { get; set; }

    public DateOnly CheckOut { get; set; }

    [Range(1, 12)]
    public int GuestsCount { get; set; }

    [Required]
    [MaxLength(25)]
    public string Status { get; set; } = "Confirmed";

    public List<int> ServiceIds { get; set; } = [];
}
