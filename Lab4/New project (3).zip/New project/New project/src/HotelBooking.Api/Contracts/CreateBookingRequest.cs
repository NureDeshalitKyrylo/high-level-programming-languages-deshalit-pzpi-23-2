using System.ComponentModel.DataAnnotations;

namespace HotelBooking.Api.Contracts;

public class CreateBookingRequest
{
    [Range(1, int.MaxValue)]
    public int RoomId { get; set; }

    [Range(1, int.MaxValue)]
    public int CustomerId { get; set; }

    public DateOnly CheckIn { get; set; }

    public DateOnly CheckOut { get; set; }

    [Range(1, 12)]
    public int GuestsCount { get; set; }

    public List<int> ServiceIds { get; set; } = [];
}
