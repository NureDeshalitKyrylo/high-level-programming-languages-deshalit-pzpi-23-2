namespace HotelBooking.Api.Contracts;

public record ServiceDto(int Id, int HotelId, string Name, decimal Price, bool IsActive);
