using System.ComponentModel.DataAnnotations;

namespace HotelBooking.Api.Contracts;

public class UpsertRoomRequest
{
    [Range(1, int.MaxValue)]
    public int HotelId { get; set; }

    [Required]
    [MaxLength(20)]
    public string Number { get; set; } = string.Empty;

    [Required]
    [MaxLength(30)]
    public string Type { get; set; } = string.Empty;

    [Range(1, 12)]
    public int Capacity { get; set; }

    [Range(0, 100000)]
    public decimal PricePerNight { get; set; }

    public bool IsActive { get; set; } = true;
}
