namespace HotelBooking.Api.Contracts;

public record BookingDto(
    int Id,
    int RoomId,
    string RoomNumber,
    int CustomerId,
    string CustomerName,
    DateOnly CheckIn,
    DateOnly CheckOut,
    int GuestsCount,
    string Status,
    decimal TotalRoomPrice,
    IReadOnlyCollection<string> Services
);
