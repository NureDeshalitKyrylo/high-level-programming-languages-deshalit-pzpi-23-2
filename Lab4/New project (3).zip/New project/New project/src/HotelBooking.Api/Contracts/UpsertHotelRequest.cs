using System.ComponentModel.DataAnnotations;

namespace HotelBooking.Api.Contracts;

public class UpsertHotelRequest
{
    [Required]
    [MaxLength(150)]
    public string Name { get; set; } = string.Empty;

    [Required]
    [MaxLength(120)]
    public string City { get; set; } = string.Empty;

    [MaxLength(250)]
    public string? Address { get; set; }
}
