namespace HotelBooking.Api.Contracts;

public record RoomDto(
    int Id,
    int HotelId,
    string HotelName,
    string Number,
    string Type,
    int Capacity,
    decimal PricePerNight
);
