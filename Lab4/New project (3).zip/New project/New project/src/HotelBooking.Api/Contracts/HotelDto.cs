namespace HotelBooking.Api.Contracts;

public record HotelDto(int Id, string Name, string City, string? Address);
