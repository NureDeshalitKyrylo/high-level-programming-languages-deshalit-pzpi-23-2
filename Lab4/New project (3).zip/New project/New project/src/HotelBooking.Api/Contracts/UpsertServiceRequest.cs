using System.ComponentModel.DataAnnotations;

namespace HotelBooking.Api.Contracts;

public class UpsertServiceRequest
{
    [Range(1, int.MaxValue)]
    public int HotelId { get; set; }

    [Required]
    [MaxLength(100)]
    public string Name { get; set; } = string.Empty;

    [Range(0, 100000)]
    public decimal Price { get; set; }

    public bool IsActive { get; set; } = true;
}
