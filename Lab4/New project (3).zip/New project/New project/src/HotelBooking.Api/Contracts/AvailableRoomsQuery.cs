using System.ComponentModel.DataAnnotations;

namespace HotelBooking.Api.Contracts;

public class AvailableRoomsQuery
{
    [Range(1, int.MaxValue)]
    public int HotelId { get; set; }

    public DateOnly CheckIn { get; set; }

    public DateOnly CheckOut { get; set; }

    [Range(1, 12)]
    public int GuestsCount { get; set; } = 1;
}
