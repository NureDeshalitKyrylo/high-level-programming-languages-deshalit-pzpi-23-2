﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace HotelBooking.Api.Migrations
{
    /// <inheritdoc />
    public partial class ExpandSeedData : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Customers",
                columns: new[] { "Id", "Email", "FirstName", "LastName", "Phone" },
                values: new object[,]
                {
                    { 3, "iryna.shevchenko@example.com", "Iryna", "Shevchenko", "+380931112244" },
                    { 4, "maksym.bondarenko@example.com", "Maksym", "Bondarenko", "+380661998877" },
                    { 5, "sofiia.tkachenko@example.com", "Sofiia", "Tkachenko", "+380731234500" },
                    { 6, "dmytro.havryliuk@example.com", "Dmytro", "Havryliuk", "+380971234111" }
                });

            migrationBuilder.InsertData(
                table: "Hotels",
                columns: new[] { "Id", "Address", "City", "Name" },
                values: new object[,]
                {
                    { 3, "Svobody Ave. 25", "Lviv", "Carpathian Escape" },
                    { 4, "Central Embankment 8", "Dnipro", "Riverside Park Hotel" }
                });

            migrationBuilder.InsertData(
                table: "Rooms",
                columns: new[] { "Id", "Capacity", "HotelId", "IsActive", "Number", "PricePerNight", "Type" },
                values: new object[,]
                {
                    { 5, 2, 1, true, "103", 3200m, "Business" },
                    { 6, 5, 2, true, "203", 6100m, "Family" }
                });

            migrationBuilder.InsertData(
                table: "Services",
                columns: new[] { "Id", "HotelId", "IsActive", "Name", "Price" },
                values: new object[,]
                {
                    { 5, 1, true, "Laundry", 300m },
                    { 6, 2, true, "Private Beach Access", 1500m }
                });

            migrationBuilder.InsertData(
                table: "Bookings",
                columns: new[] { "Id", "CheckIn", "CheckOut", "CreatedAtUtc", "CustomerId", "GuestsCount", "RoomId", "Status" },
                values: new object[,]
                {
                    { 2, new DateOnly(2026, 6, 18), new DateOnly(2026, 6, 22), new DateTime(2026, 5, 22, 9, 30, 0, 0, DateTimeKind.Utc), 3, 3, 3, "Confirmed" },
                    { 5, new DateOnly(2026, 6, 20), new DateOnly(2026, 6, 24), new DateTime(2026, 5, 27, 11, 10, 0, 0, DateTimeKind.Utc), 6, 1, 5, "Pending" }
                });

            migrationBuilder.InsertData(
                table: "Rooms",
                columns: new[] { "Id", "Capacity", "HotelId", "IsActive", "Number", "PricePerNight", "Type" },
                values: new object[,]
                {
                    { 7, 2, 3, true, "301", 2100m, "Standard" },
                    { 8, 3, 3, true, "302", 3600m, "Deluxe" },
                    { 9, 4, 3, true, "303", 4900m, "Suite" },
                    { 10, 2, 4, true, "401", 2400m, "Standard" },
                    { 11, 3, 4, true, "402", 3800m, "Deluxe" },
                    { 12, 4, 4, true, "403", 5200m, "Apartment" }
                });

            migrationBuilder.InsertData(
                table: "Services",
                columns: new[] { "Id", "HotelId", "IsActive", "Name", "Price" },
                values: new object[,]
                {
                    { 7, 3, true, "Mountain Tour", 1800m },
                    { 8, 3, true, "Breakfast", 400m },
                    { 9, 4, true, "Conference Hall", 2500m },
                    { 10, 4, true, "Parking", 250m }
                });

            migrationBuilder.InsertData(
                table: "BookingServices",
                columns: new[] { "BookingsId", "ServicesId" },
                values: new object[,]
                {
                    { 2, 3 },
                    { 2, 6 },
                    { 5, 2 },
                    { 5, 5 }
                });

            migrationBuilder.InsertData(
                table: "Bookings",
                columns: new[] { "Id", "CheckIn", "CheckOut", "CreatedAtUtc", "CustomerId", "GuestsCount", "RoomId", "Status" },
                values: new object[,]
                {
                    { 3, new DateOnly(2026, 6, 8), new DateOnly(2026, 6, 11), new DateTime(2026, 5, 24, 14, 15, 0, 0, DateTimeKind.Utc), 4, 2, 7, "Confirmed" },
                    { 4, new DateOnly(2026, 6, 15), new DateOnly(2026, 6, 17), new DateTime(2026, 5, 25, 16, 45, 0, 0, DateTimeKind.Utc), 5, 2, 11, "Confirmed" }
                });

            migrationBuilder.InsertData(
                table: "BookingServices",
                columns: new[] { "BookingsId", "ServicesId" },
                values: new object[,]
                {
                    { 3, 7 },
                    { 3, 8 },
                    { 4, 10 }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "BookingServices",
                keyColumns: new[] { "BookingsId", "ServicesId" },
                keyValues: new object[] { 2, 3 });

            migrationBuilder.DeleteData(
                table: "BookingServices",
                keyColumns: new[] { "BookingsId", "ServicesId" },
                keyValues: new object[] { 2, 6 });

            migrationBuilder.DeleteData(
                table: "BookingServices",
                keyColumns: new[] { "BookingsId", "ServicesId" },
                keyValues: new object[] { 3, 7 });

            migrationBuilder.DeleteData(
                table: "BookingServices",
                keyColumns: new[] { "BookingsId", "ServicesId" },
                keyValues: new object[] { 3, 8 });

            migrationBuilder.DeleteData(
                table: "BookingServices",
                keyColumns: new[] { "BookingsId", "ServicesId" },
                keyValues: new object[] { 4, 10 });

            migrationBuilder.DeleteData(
                table: "BookingServices",
                keyColumns: new[] { "BookingsId", "ServicesId" },
                keyValues: new object[] { 5, 2 });

            migrationBuilder.DeleteData(
                table: "BookingServices",
                keyColumns: new[] { "BookingsId", "ServicesId" },
                keyValues: new object[] { 5, 5 });

            migrationBuilder.DeleteData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 6);

            migrationBuilder.DeleteData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 8);

            migrationBuilder.DeleteData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 9);

            migrationBuilder.DeleteData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 10);

            migrationBuilder.DeleteData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 12);

            migrationBuilder.DeleteData(
                table: "Services",
                keyColumn: "Id",
                keyValue: 9);

            migrationBuilder.DeleteData(
                table: "Bookings",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Bookings",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Bookings",
                keyColumn: "Id",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "Bookings",
                keyColumn: "Id",
                keyValue: 5);

            migrationBuilder.DeleteData(
                table: "Services",
                keyColumn: "Id",
                keyValue: 5);

            migrationBuilder.DeleteData(
                table: "Services",
                keyColumn: "Id",
                keyValue: 6);

            migrationBuilder.DeleteData(
                table: "Services",
                keyColumn: "Id",
                keyValue: 7);

            migrationBuilder.DeleteData(
                table: "Services",
                keyColumn: "Id",
                keyValue: 8);

            migrationBuilder.DeleteData(
                table: "Services",
                keyColumn: "Id",
                keyValue: 10);

            migrationBuilder.DeleteData(
                table: "Customers",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Customers",
                keyColumn: "Id",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "Customers",
                keyColumn: "Id",
                keyValue: 5);

            migrationBuilder.DeleteData(
                table: "Customers",
                keyColumn: "Id",
                keyValue: 6);

            migrationBuilder.DeleteData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 5);

            migrationBuilder.DeleteData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 7);

            migrationBuilder.DeleteData(
                table: "Rooms",
                keyColumn: "Id",
                keyValue: 11);

            migrationBuilder.DeleteData(
                table: "Hotels",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Hotels",
                keyColumn: "Id",
                keyValue: 4);
        }
    }
}
