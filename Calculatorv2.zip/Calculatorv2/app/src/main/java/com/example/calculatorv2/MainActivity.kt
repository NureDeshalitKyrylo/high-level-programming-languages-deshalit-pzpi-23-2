package com.example.calculatorv2

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    private lateinit var etNumber1: EditText
    private lateinit var etNumber2: EditText
    private lateinit var btnCalculate: Button
    private lateinit var tvResult: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        etNumber1 = findViewById(R.id.etNumber1)
        etNumber2 = findViewById(R.id.etNumber2)
        btnCalculate = findViewById(R.id.btnCalculate)
        tvResult = findViewById(R.id.tvResult)

        btnCalculate.setOnClickListener {
            calculateSum()
        }
    }

    private fun calculateSum() {
        val input1 = etNumber1.text.toString()
        val input2 = etNumber2.text.toString()

        if (input1.isEmpty() || input2.isEmpty()) {
            tvResult.text = "Будь ласка, введіть обидва числа"
            return
        }

        val number1 = input1.toDouble()
        val number2 = input2.toDouble()
        val sum = number1 + number2

        tvResult.text = "Сума: $sum"
    }
}