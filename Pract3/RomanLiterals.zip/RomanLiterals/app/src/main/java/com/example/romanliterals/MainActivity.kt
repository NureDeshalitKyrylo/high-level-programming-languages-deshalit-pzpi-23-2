package com.example.romanliterals

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val romanValues = mapOf(
        'I' to 1,
        'V' to 5,
        'X' to 10,
        'L' to 50,
        'C' to 100,
        'D' to 500,
        'M' to 1000
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etRoman   = findViewById<EditText>(R.id.etRoman)
        val btnConvert = findViewById<Button>(R.id.btnConvert)
        val tvResult  = findViewById<TextView>(R.id.tvResult)

        btnConvert.setOnClickListener {
            val input = etRoman.text.toString().trim().uppercase()

            if (input.isEmpty()) {
                tvResult.text = "Введіть число"
                return@setOnClickListener
            }

            val result = toArabic(input)

            if (result == -1) {
                tvResult.text = "Невірне римське число"
            } else {
                tvResult.text = "$input = $result"
            }
        }
    }

    private fun toArabic(roman: String): Int {

        if (roman.any { it !in romanValues }) return -1

        for (ch in listOf('V', 'L', 'D')) {
            if (roman.count { it == ch } > 1) return -1
        }

        if (Regex("(.)\\1{3}").containsMatchIn(roman)) return -1

        val values = mutableListOf<Int>()
        var i = 0
        while (i < roman.length) {
            val cur  = romanValues[roman[i]]!!
            val next = if (i + 1 < roman.length) romanValues[roman[i + 1]]!! else 0

            if (cur < next) {
                if(cur * 10 < next || cur * 2 == next)
                {
                   return -1
                }

                values.add(next - cur)
                i += 2
            } else {
                values.add(cur)
                i += 1
            }
        }

        for (j in 1 until values.size) {
            if (values[j] > values[j - 1]) return -1
        }

        return values.sum()
    }
}