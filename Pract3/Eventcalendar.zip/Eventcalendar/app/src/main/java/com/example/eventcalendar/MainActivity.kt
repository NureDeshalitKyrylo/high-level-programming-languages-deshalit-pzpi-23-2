package com.example.eventcalendar

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private val events = mutableMapOf<String, MutableList<String>>()

    private val dateFormat = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())
    private var selectedDate = dateFormat.format(Date())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val calendarView = findViewById<CalendarView>(R.id.calendarView)
        val etEvent      = findViewById<EditText>(R.id.etEvent)
        val btnAdd       = findViewById<Button>(R.id.btnAdd)
        val tvDate       = findViewById<TextView>(R.id.tvSelectedDate)
        val lvEvents     = findViewById<ListView>(R.id.lvEvents)

        tvDate.text = "Події на $selectedDate"

        calendarView.setOnDateChangeListener { _, year, month, day ->
            selectedDate = "%02d.%02d.%04d".format(day, month + 1, year)
            tvDate.text = "Події на $selectedDate"
            refreshList(lvEvents)
        }

        btnAdd.setOnClickListener {
            val text = etEvent.text.toString().trim()
            if (text.isEmpty()) {
                Toast.makeText(this, "Введіть назву події", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            events.getOrPut(selectedDate) { mutableListOf() }.add(text)
            etEvent.text.clear()
            refreshList(lvEvents)
        }
    }


    private fun refreshList(listView: ListView) {
        val list = events[selectedDate] ?: emptyList<String>()
        listView.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, list)
    }
}